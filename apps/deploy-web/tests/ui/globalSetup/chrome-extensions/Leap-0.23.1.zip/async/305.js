!(function () {
  try {
    var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "7aea0c26-c41b-4ce4-8f86-ecd2f6bd8042"),
      (e._sentryDebugIdIdentifier = "sentry-dbid-7aea0c26-c41b-4ce4-8f86-ecd2f6bd8042"));
  } catch (e) {}
})();
var _global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
_global.SENTRY_RELEASE = { id: "0.23.1" };
("use strict");
(self.webpackChunk_leap_cosmos_extension = self.webpackChunk_leap_cosmos_extension || []).push([
  ["305"],
  {
    94562: function (e, t, n) {
      n.d(t, { X: () => i });
      var a = n(52322),
        s = n(62695),
        r = n(15256),
        l = n(2784),
        c = n(70514);
      let i = l.forwardRef((e, t) => {
        let { className: n, ...l } = e;
        return (0, a.jsx)(r.fC, {
          ref: t,
          className: (0, c.cn)(
            "peer h-4 w-4 shrink-0 rounded-sm data-[state=checked]:border border-accent-green shadow focus-visible:outline-none focus-visible:ring-1 focus-visible:ring-ring disabled:cursor-not-allowed disabled:opacity-50 data-[state=checked]:!bg-accent-green data-[state=checked]:text-accent-green !bg-secondary-300",
            n
          ),
          ...l,
          children: (0, a.jsx)(r.z$, {
            className: "flex items-center justify-center text-current",
            children: (0, a.jsx)(s.J, { className: "h-4 w-4 text-secondary-300" })
          })
        });
      });
      i.displayName = r.fC.displayName;
    },
    98622: function (e, t, n) {
      n.d(t, { z: () => l });
      var a = n(52322),
        s = n(4370);
      n(2784);
      var r = n(70514);
      let l = e => {
        let { className: t, children: n, ...l } = e;
        return (0, a.jsx)(s.E.div, {
          className: (0, r.cn)("overflow-auto bg-secondary overflow-x-hidden my-auto mx-auto rounded-3xl flex h-full w-full", t),
          ...l,
          children: n
        });
      };
    },
    47149: function (e, t, n) {
      n.a(e, async function (e, a) {
        try {
          n.d(t, { n: () => f });
          var s = n(52322),
            r = n(15969),
            l = n(91486),
            c = n(4370),
            i = n(53542),
            o = n(91729),
            d = n(2784),
            u = e([i]);
          i = (u.then ? (await u)() : u)[0];
          let f = e => {
            let { Icon: t, title: n, cta: a, moveToNextApp: u, appType: f } = e;
            return (
              (0, d.useEffect)(() => {
                let e = setInterval(async () => {
                  try {
                    (await (0, r.qn$)(f === i.Yg.ETH ? "Ethereum" : "Cosmos")) && (u(f), clearInterval(e));
                  } catch (e) {
                    console.error(e);
                  }
                }, 1e3);
                return () => {
                  clearInterval(e);
                };
              }, [f]),
              (0, s.jsxs)(c.E.div, {
                className: "flex flex-col w-full flex-1",
                variants: o.S,
                initial: "fromRight",
                animate: "animate",
                exit: "exit",
                children: [
                  (0, s.jsxs)("header", {
                    className: "flex flex-col items-center justify-center gap-6 flex-1",
                    children: [
                      (0, s.jsx)("div", {
                        className:
                          "rounded-full size-[134px] animate-scaleUpDown [--scale-up-down-start:1.05] bg-accent-foreground/20 grid place-content-center",
                        children: (0, s.jsx)("div", {
                          className:
                            "rounded-full size-[89px] animate-scaleUpDown [--scale-up-down-start:1.075] bg-accent-foreground/40 grid place-content-center",
                          children: (0, s.jsx)("div", {
                            className:
                              "rounded-full size-[44.5px] animate-scaleUpDown [--scale-up-down-start:1.1] bg-accent-foreground grid place-content-center",
                            children: (0, s.jsx)(t, { className: "size-6" })
                          })
                        })
                      }),
                      (0, s.jsx)("span", { className: "text-xl font-bold text-center", children: n })
                    ]
                  }),
                  !!(a && u) && (0, s.jsx)(l.zx, { className: "w-full", onClick: () => u(f), children: a })
                ]
              })
            );
          };
          a();
        } catch (e) {
          a(e);
        }
      });
    },
    31109: function (e, t, n) {
      n.a(e, async function (e, a) {
        try {
          n.r(t), n.d(t, { default: () => x });
          var s = n(52322),
            r = n(14981),
            l = n(98622);
          n(2784);
          var c = n(64418),
            i = n(25016),
            o = n(70759),
            d = n(46389),
            u = n(38802),
            f = e([u, d]);
          [u, d] = f.then ? (await f)() : f;
          let m = () => {
            let { currentStep: e } = (0, i.bV)();
            return (0, s.jsxs)(r.M, {
              mode: "wait",
              initial: !1,
              presenceAffectsLayout: !0,
              children: [0 === e && (0, s.jsx)(u.Z, {}), 1 === e && (0, s.jsx)(d.U, {}), 2 === e && (0, s.jsx)(o.V, {})]
            });
          };
          function x() {
            return (0, s.jsx)(l.z, {
              className: "flex flex-col gap-y-5 justify-center items-center grow p-7",
              children: (0, s.jsxs)(i.V0, { children: [(0, s.jsx)(c.l, {}), (0, s.jsx)(m, {})] })
            });
          }
          a();
        } catch (e) {
          a(e);
        }
      });
    },
    64418: function (e, t, n) {
      n.d(t, { l: () => i });
      var a = n(52322),
        s = n(43166),
        r = n(91486);
      n(2784);
      var l = n(70514),
        c = n(25016);
      let i = () => {
        let { backToPreviousStep: e, currentStep: t } = (0, c.bV)();
        return (0, a.jsx)("div", {
          className: (0, l.cn)("flex flex-row items-center justify-between relative w-full -m-1", 2 === t && "hidden"),
          children: (0, a.jsx)(r.zx, { variant: "secondary", size: "icon", onClick: e, className: "w-fit", children: (0, a.jsx)(s.X, { className: "size-4" }) })
        });
      };
    },
    25016: function (e, t, n) {
      n.d(t, { V0: () => d, bV: () => o });
      var a = n(52322),
        s = n(41172),
        r = n(47013),
        l = n(2784),
        c = n(10289);
      let i = (0, l.createContext)({
          ledgerNetworks: new Set(),
          setLedgerNetworks: () => {},
          prevStep: 0,
          currentStep: 0,
          setCurrentStep: () => {},
          moveToNextStep: () => {},
          backToPreviousStep: () => {},
          reconnectLedger: e => Promise.resolve()
        }),
        o = () => {
          let e = (0, l.useContext)(i);
          if (!e) throw Error("useReconnectLedgerContext must be used within a ReconnectLedgerProvider");
          return e;
        },
        d = e => {
          let { children: t } = e,
            [n, o] = (0, l.useState)(new Set()),
            d = (0, c.s0)(),
            [u, f] = (0, l.useState)(0),
            x = (0, r.Z)(u) || 0,
            m = async () => {
              u > 0 ? f(u - 1) : d(-1);
            },
            h = async e => {},
            p = (0, s.NrF)(u, 100);
          return (0, a.jsx)(i.Provider, {
            value: {
              ledgerNetworks: n,
              setLedgerNetworks: o,
              prevStep: x,
              currentStep: p,
              setCurrentStep: f,
              moveToNextStep: () => {
                f(u + 1);
              },
              backToPreviousStep: m,
              reconnectLedger: h
            },
            children: t
          });
        };
    },
    70759: function (e, t, n) {
      n.d(t, { V: () => u });
      var a = n(52322),
        s = n(91486),
        r = n(30464);
      n(2784);
      var l = n(43579),
        c = n.n(l),
        i = n(28316),
        o = n(48534);
      let d = () =>
        (0, a.jsx)(c(), {
          className: "w-full h-full absolute opacity-50 top-0 left-0 right-0 z-10 isolate",
          onInit: e => {
            let { conductor: t } = e;
            t.run({ speed: 1 }),
              setTimeout(() => {
                t.stop();
              }, 5e3);
          },
          globalOptions: { useWorker: !0, resize: !0 }
        });
      function u() {
        return (0, a.jsxs)(a.Fragment, {
          children: [
            (0, i.createPortal)((0, a.jsx)(a.Fragment, { children: (0, a.jsx)(d, {}) }), document.body),
            (0, a.jsxs)("div", {
              className: "flex flex-col gap-y-8 my-auto z-20",
              children: [
                (0, a.jsx)("div", {
                  className: "w-32 h-auto mx-auto",
                  children: (0, a.jsx)("img", { src: r.r.Misc.OnboardingFrog, className: "w-full h-full" })
                }),
                (0, a.jsxs)("header", {
                  className: "flex flex-col gap-y-5 items-center text-center",
                  children: [
                    (0, a.jsx)("h1", { className: "font-bold text-xxl", children: "You are all set!" }),
                    (0, a.jsx)("span", {
                      className: "flex flex-col gap-y-1 text-muted-foreground text-md",
                      children: "Close this page and retry your previous transaction."
                    })
                  ]
                })
              ]
            }),
            (0, a.jsx)(s.zx, {
              className: "w-full z-20",
              onClick: () => {
                (0, o.mW)("https://app.leapwallet.io");
              },
              children: "Open Leap Extension"
            })
          ]
        });
      }
    },
    46389: function (e, t, n) {
      n.a(e, async function (e, a) {
        try {
          n.d(t, { U: () => m });
          var s = n(52322),
            r = n(14981),
            l = n(19269),
            c = n(53542),
            i = n(2784),
            o = n(47149),
            d = n(25016),
            u = n(38802),
            f = n(19054),
            x = e([u, o, c]);
          [u, o, c] = x.then ? (await x)() : x;
          let m = () => {
            let [e, t] = (0, i.useState)(),
              [n, a] = (0, i.useState)(new Set()),
              { moveToNextStep: x, ledgerNetworks: m, prevStep: h, currentStep: p, setCurrentStep: g } = (0, d.bV)();
            (0, i.useEffect)(() => {
              let e = u.p.find(e => m.has(e.id));
              e ? (a(t => t.add(e.id)), t(e.id)) : g(e => e - 1);
            }, []);
            let b = (0, i.useCallback)(
              e => {
                let s = u.p.find(t => t.id !== e && !n.has(t.id) && m.has(t.id));
                s ? (a(e => e.add(s.id)), t(s.id)) : (t(void 0), x());
              },
              [n, m, x]
            );
            if (m.size > 0 && e)
              return (0, s.jsx)(f.W, {
                heading: "",
                entry: h <= p ? "right" : "left",
                children: (0, s.jsx)(r.M, {
                  mode: "wait",
                  initial: !1,
                  presenceAffectsLayout: !0,
                  children: (0, s.jsx)(
                    o.n,
                    { title: `Open ${e === c.Yg.ETH ? "Ethereum" : "Cosmos"} app on your ledger`, Icon: l.z, appType: e, moveToNextApp: b },
                    `hold-state-${e}`
                  )
                })
              });
          };
          a();
        } catch (e) {
          a(e);
        }
      });
    },
    38802: function (e, t, n) {
      n.a(e, async function (e, a) {
        try {
          n.d(t, { Z: () => p, p: () => m });
          var s = n(52322),
            r = n(91486),
            l = n(94562),
            c = n(74229),
            i = n(30464),
            o = n(53542);
          n(2784);
          var d = n(49409),
            u = n(25016),
            f = n(19054),
            x = e([o]);
          let m = [
              { id: (o = (x.then ? (await x)() : x)[0]).Yg.COSMOS, img: i.r.Logos.Cosmos, title: "COSMOS", subText: "OSMO, ATOM & 4 more" },
              { id: o.Yg.ETH, img: i.r.Logos.Ethereum, title: "EVM", subText: "ETH, AVAX, BASE & 5 more" }
            ],
            h = e => {
              let t = (0, c.a1)();
              return (0, s.jsxs)("label", {
                className:
                  "flex flex-row gap-[14px] items-center p-5 border-b border-secondary-600/25 last:border-b-0 bg-secondary-200 hover:bg-secondary-300/75 transition-colors cursor-pointer text-start",
                children: [
                  (0, s.jsx)("img", { src: e.img || t, alt: e.title, onError: (0, d._)(t), className: "size-10 rounded-full" }),
                  (0, s.jsxs)("div", {
                    className: "flex flex-col",
                    children: [
                      (0, s.jsx)("h3", { className: "text-md font-bold", children: e.title }),
                      (0, s.jsx)("p", { className: "text-sm font-medium text-muted-foreground", children: e.subText })
                    ]
                  }),
                  (0, s.jsx)(l.X, { className: "ml-auto", checked: e.checked, onCheckedChange: e.onCheckedChange })
                ]
              });
            },
            p = () => {
              let { ledgerNetworks: e, prevStep: t, currentStep: n, setLedgerNetworks: a, moveToNextStep: l } = (0, u.bV)();
              return (0, s.jsxs)(f.W, {
                heading: "Select networks",
                subHeading: "Select networks you want to connect with",
                entry: t <= n ? "right" : "left",
                children: [
                  (0, s.jsx)("div", {
                    className: "flex flex-col rounded-xl overflow-hidden py-1",
                    children: m.map(t =>
                      (0, s.jsx)(
                        h,
                        {
                          ...t,
                          checked: e.has(t.id),
                          onCheckedChange: e => {
                            a(n => {
                              let a = new Set(n);
                              return e ? a.add(t.id) : a.delete(t.id), a;
                            });
                          }
                        },
                        t.id
                      )
                    )
                  }),
                  (0, s.jsx)(r.zx, {
                    disabled: 0 === e.size,
                    className: "w-full mt-auto",
                    onClick: l,
                    "aria-label": "send proceed button in reconnect ledger flow",
                    children: (0, s.jsx)("span", { "aria-label": "send proceed button text in reconnect ledger flow", children: "Proceed" })
                  })
                ]
              });
            };
          a();
        } catch (e) {
          a(e);
        }
      });
    },
    19054: function (e, t, n) {
      n.d(t, { W: () => i });
      var a = n(52322),
        s = n(4370);
      n(2784);
      var r = n(70514),
        l = n(46338);
      let c = {
          fromLeft: { opacity: 0, x: -25, transition: l.eR },
          fromRight: { opacity: 0, x: 25, transition: l.eR },
          animate: { opacity: 1, x: 0, transition: l.eR },
          exit: { opacity: 0, x: 0, transition: { ...l.eR, duration: 0.15 } }
        },
        i = e => {
          let { children: t, heading: n, subHeading: l, className: i, entry: o = "right", headerIcon: d } = e;
          return (0, a.jsxs)(s.E.div, {
            className: (0, r.cn)("flex flex-col items-stretch w-full h-full gap-7", i),
            variants: c,
            initial: "left" === o ? "fromLeft" : "fromRight",
            animate: "animate",
            exit: "exit",
            children: [
              (0, a.jsxs)("header", {
                className: "flex flex-col items-center gap-1",
                children: [
                  d && (0, a.jsx)("div", { className: "size-16 bg-secondary-200 rounded-full grid place-content-center", children: d }),
                  (0, a.jsx)("h1", { className: "font-bold text-[1.5rem] text-center", children: n }),
                  l && (0, a.jsx)("div", { className: "text-[0.875rem] font-medium text-muted-foreground leading-[1.4rem] text-center", children: l })
                ]
              }),
              t
            ]
          });
        };
    }
  }
]);
//# sourceMappingURL=305.js.map
