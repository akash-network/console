!(function () {
  try {
    var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "9f8a636d-ec7b-4035-860e-f3ca1036cf51"),
      (e._sentryDebugIdIdentifier = "sentry-dbid-9f8a636d-ec7b-4035-860e-f3ca1036cf51"));
  } catch (e) {}
})();
var _global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
_global.SENTRY_RELEASE = { id: "0.23.1" };
("use strict");
(self.webpackChunk_leap_cosmos_extension = self.webpackChunk_leap_cosmos_extension || []).push([
  ["5884"],
  {
    71845: function (e, t, r) {
      r.d(t, { Z: () => d });
      var s = r(52322),
        l = r(6806),
        a = r(2784);
      let i = new Map([
          [
            "regular",
            (0, s.jsxs)(
              a.Fragment,
              {
                children: [
                  (0, s.jsxs)("g", {
                    clipPath: "url(#clip0_241_1099)",
                    children: [
                      (0, s.jsx)("path", {
                        d: "M3 12.75H14.0625",
                        stroke: "currentColor",
                        strokeWidth: "1.5",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                      }),
                      (0, s.jsx)("path", { d: "M3 8.25H21", stroke: "currentColor", strokeWidth: "1.5", strokeLinecap: "round", strokeLinejoin: "round" }),
                      (0, s.jsx)("path", { d: "M3 17.25H7.125", stroke: "currentColor", strokeWidth: "1.5", strokeLinecap: "round", strokeLinejoin: "round" })
                    ]
                  }),
                  (0, s.jsx)("defs", {
                    children: (0, s.jsx)("clipPath", {
                      id: "clip0_241_1099",
                      children: (0, s.jsx)("rect", { width: "24", height: "24", fill: "currentColor" })
                    })
                  })
                ]
              },
              "regular"
            )
          ],
          [
            "bold",
            (0, s.jsxs)(
              a.Fragment,
              {
                children: [
                  (0, s.jsxs)("g", {
                    clipPath: "url(#clip0_256_253)",
                    children: [
                      (0, s.jsx)("path", {
                        d: "M3 12.75H14.0625",
                        stroke: "currentColor",
                        strokeWidth: "2.25",
                        strokeLinecap: "round",
                        strokeLinejoin: "round"
                      }),
                      (0, s.jsx)("path", { d: "M3 8.25H21", stroke: "currentColor", strokeWidth: "2.25", strokeLinecap: "round", strokeLinejoin: "round" }),
                      (0, s.jsx)("path", { d: "M3 17.25H7.125", stroke: "currentColor", strokeWidth: "2.25", strokeLinecap: "round", strokeLinejoin: "round" })
                    ]
                  }),
                  (0, s.jsx)("defs", {
                    children: (0, s.jsx)("clipPath", { id: "clip0_256_253", children: (0, s.jsx)("rect", { width: "24", height: "24", fill: "currentColor" }) })
                  })
                ]
              },
              "bold"
            )
          ],
          [
            "fill",
            (0, s.jsx)(
              "path",
              {
                fillRule: "evenodd",
                clipRule: "evenodd",
                d: "M4 0H20C22.2091 0 24 1.79086 24 4V20C24 22.2091 22.2091 24 20 24H4C1.79086 24 0 22.2091 0 20V4C0 1.79086 1.79086 0 4 0ZM3 12C2.58579 12 2.25 12.3358 2.25 12.75C2.25 13.1642 2.58579 13.5 3 13.5H14.0625C14.4767 13.5 14.8125 13.1642 14.8125 12.75C14.8125 12.3358 14.4767 12 14.0625 12H3ZM2.25 8.25C2.25 7.83579 2.58579 7.5 3 7.5H21C21.4142 7.5 21.75 7.83579 21.75 8.25C21.75 8.66421 21.4142 9 21 9H3C2.58579 9 2.25 8.66421 2.25 8.25ZM3 16.5C2.58579 16.5 2.25 16.8358 2.25 17.25C2.25 17.6642 2.58579 18 3 18H7.125C7.53921 18 7.875 17.6642 7.875 17.25C7.875 16.8358 7.53921 16.5 7.125 16.5H3Z",
                fill: "currentColor"
              },
              "fill"
            )
          ]
        ]),
        n = (0, a.forwardRef)((e, t) => (0, s.jsx)(l.Z, { viewBox: "0 0 24 24", ref: t, ...e, weights: i }));
      n.displayName = "Sort";
      let d = n;
    },
    72591: function (e, t, r) {
      r.d(t, { d: () => x });
      var s = r(52322),
        l = r(41172),
        a = r(75377),
        i = r(26227),
        n = r(14281),
        d = r(2784),
        o = r(46103);
      let c = { tvl: "Total Volume Locked (TVL)", apr: "Annual Percentage Return (APR)" },
        x = e => {
          let { isOpen: t, onClose: r, settings: x, onSettingsChange: m } = e,
            u = Object.entries(c),
            h = (0, l.a74)();
          return (0, s.jsx)(n.Z, {
            isOpen: t,
            onClose: r,
            title: "Sort by",
            closeOnBackdropClick: !0,
            children: (0, s.jsx)("div", {
              className: "rounded-2xl flex flex-col items-center w-full justify-center dark:bg-gray-900 bg-white-100",
              children: u.map((e, t) => {
                let [r, l] = e;
                return (0, s.jsxs)(
                  d.Fragment,
                  {
                    children: [
                      (0, s.jsxs)("button", {
                        className: "flex items-center justify-between text-md font-bold p-4 w-full text-gray-800 dark:text-white-100",
                        onClick: () => {
                          m({ ...x, sortBy: r });
                        },
                        children: [
                          (0, s.jsx)("span", { children: l }),
                          x.sortBy === r ? (0, s.jsx)(i.f, { weight: "fill", size: 24, style: { color: o.w.getChainColor(h) } }) : null
                        ]
                      }),
                      t === u.length - 1 ? null : (0, s.jsx)(a.CardDivider, {})
                    ]
                  },
                  r
                );
              })
            })
          });
        };
    },
    73024: function (e, t, r) {
      r.a(e, async function (e, s) {
        try {
          r.r(t), r.d(t, { default: () => y });
          var l = r(52322),
            a = r(75377),
            i = r(78944),
            n = r(27963),
            d = r(78454),
            o = r(74229),
            c = r(10706),
            x = r(71845),
            m = r(29750),
            u = r(75958),
            h = r(7345),
            p = r(2784),
            g = r(32796),
            f = r(72591),
            j = r(91545),
            b = e([c, d, i, h]);
          [c, d, i, h] = b.then ? (await b)() : b;
          let y = (0, u.Pi)(e => {
            let { chainTagsStore: t } = e,
              [r, s] = (0, p.useState)(!1),
              [u, b] = (0, p.useState)(!1),
              [y, k] = (0, p.useState)(!1),
              { activeWallet: N } = (0, c.ZP)(),
              { headerChainImgSrc: v } = (0, o.Cd)(),
              [w, C] = (0, p.useState)({ sortBy: "tvl" });
            return N
              ? (0, l.jsxs)("div", {
                  className: "relative w-full overflow-clip panel-height",
                  children: [
                    (0, l.jsxs)(d.Z, {
                      header: (0, l.jsx)(a.Header, {
                        action: {
                          onClick: () => g.r.toggleSideNav(),
                          type: a.HeaderActionType.NAVIGATION,
                          className: "min-w-[48px] h-[36px] px-2 bg-[#FFFFFF] dark:bg-gray-900 hover:bg-gray-100 dark:hover:bg-gray-800 rounded-full"
                        },
                        imgSrc: v,
                        onImgClick: () => b(!0),
                        title: "Earn"
                      }),
                      children: [
                        (0, l.jsx)(i.hN, {}),
                        (0, l.jsxs)("div", {
                          className: "w-full px-7 pt-7 mb-[84px]",
                          children: [
                            (0, l.jsx)("div", {
                              className: "mb-5",
                              children: (0, l.jsxs)("div", {
                                className: "flex justify-between items-baseline",
                                children: [
                                  (0, l.jsxs)("div", {
                                    children: [
                                      (0, l.jsx)("h2", { className: "text-[28px] text-black-100 dark:text-white-100 font-bold w-[194px]", children: "Earn" }),
                                      (0, l.jsx)("h3", { className: "text-sm text-gray-600 font-bold", children: "Invest your crypto and earn rewards" })
                                    ]
                                  }),
                                  (0, l.jsx)("button", {
                                    className: "flex items-center justify-center h-9 w-9 bg-white-100 dark:bg-gray-900 rounded-full ml-3",
                                    onClick: () => k(!0),
                                    children: (0, l.jsx)(x.Z, { size: 20, className: "dark:text-white-100 text-gray-800" })
                                  })
                                ]
                              })
                            }),
                            (0, l.jsx)(j.Z, { displaySettings: w })
                          ]
                        }),
                        (0, l.jsx)(f.d, { isOpen: y, onClose: () => k(!1), settings: w, onSettingsChange: C })
                      ]
                    }),
                    (0, l.jsx)(h.Z, { isVisible: u, onClose: () => b(!1), chainTagsStore: t })
                  ]
                })
              : (0, l.jsx)("div", {
                  className: "relative w-full overflow-clip panel-height",
                  children: (0, l.jsx)(d.Z, { children: (0, l.jsx)("div", { children: (0, l.jsx)(n.S, { src: m.LeapCosmos, heading: "No wallet found" }) }) })
                });
          });
          s();
        } catch (e) {
          s(e);
        }
      });
    },
    91545: function (e, t, r) {
      r.d(t, { Z: () => j });
      var s = r(52322),
        l = r(41172),
        a = r(86200),
        i = r(2784),
        n = r(14281),
        d = r(14482),
        o = r(65953),
        c = r(6391),
        x = r.n(c),
        m = r(23259),
        u = r(57124),
        h = r(49409);
      let p = e => {
          let { product: t, productDapp: r } = e,
            l = (0, u.a)();
          return (0, s.jsx)("li", {
            className: "!m-0 px-4 group/item",
            children: (0, s.jsxs)("a", {
              className: "flex justify-start items-center py-3 gap-2 border-b border-b-gray-100 dark:border-b-gray-800 group-last-of-type/item:border-b-0",
              target: "_blank",
              rel: "noopener noreferrer",
              href: "liquidStaking" === t.dappCategory ? `${m.x3}/staking/liquid` : t.productWebsite,
              children: [
                (0, s.jsxs)("div", {
                  className: "flex items-center flex-[6] flex-grow-0 gap-2",
                  title: `${t.dappName}: ${t.productName}`,
                  children: [
                    (0, s.jsx)("img", { src: r.logo, onError: (0, h._)(l), className: "h-8 w-8", title: r.name }),
                    (0, s.jsx)("p", {
                      className: "text-gray-900 dark:text-white-100 font-bold text-xs leading-3 w-[160px] whitespace-normal",
                      children: t.productName
                    })
                  ]
                }),
                (0, s.jsx)("p", {
                  className: "flex-[1] text-center font-bold text-orange-300 text-xs",
                  children: Intl.NumberFormat("en-US", { style: "currency", currency: "USD", notation: "compact" }).format(t.tvl)
                }),
                (0, s.jsxs)("p", {
                  className: `flex-[1] text-center font-bold text-xs ${t.apr > 0 ? "text-green-500" : "text-red-300"}`,
                  children: [new (x())(100 * t.apr).toFixed(2), "%"]
                }),
                (0, s.jsx)("img", { src: o.RightArrow, alt: "right arrow", className: "ml-2 justify-self-end opacity-50" })
              ]
            })
          });
        },
        g = e => {
          let { products: t, dapps: r, categoryId: l, sortBy: a } = e,
            n = (0, i.useMemo)(
              () =>
                t
                  .filter(e => {
                    var t;
                    let s = e.dappCategory === l,
                      a = e.visible,
                      i = (null === (t = r.find(t => e.chain === t.chain && e.dappName === t.name)) || void 0 === t ? void 0 : t.visible) ?? !1;
                    return s && a && i;
                  })
                  .sort((e, t) => Number(t[a]) - Number(e[a])),
              [l, r, t, a]
            );
          return (0, s.jsx)("ul", {
            className: "mt-3 rounded-2xl overflow-hidden list-none dark:bg-[#212121] bg-white-100 py-[2px]",
            children: n.map(e => {
              let t = r.find(t => e.chain === t.chain && e.dappName === t.name);
              return t ? (0, s.jsx)(p, { product: e, productDapp: t }, `${e.chain}_${e.dappName}_${e.productName}`) : null;
            })
          });
        },
        f = e => {
          let { data: t, displaySettings: r } = e,
            [l, a] = (0, i.useState)(),
            { dappCategories: c, dapps: x, products: m, disclaimer: u } = t,
            h = (0, i.useMemo)(() => Object.values(x), [x]),
            p = (0, i.useMemo)(() => Object.values(m), [m]),
            f = (0, i.useMemo)(
              () =>
                Object.entries(c)
                  .filter(e => {
                    let [t, r] = e;
                    return !!(
                      r.visible &&
                      p.some(e => {
                        var r;
                        let s = e.dappCategory === t,
                          l = e.visible,
                          a = (null === (r = h.find(t => e.chain === t.chain && e.dappName === t.name)) || void 0 === r ? void 0 : r.visible) ?? !1;
                        return s && l && a;
                      })
                    );
                  })
                  .sort((e, t) => {
                    let [, r] = e,
                      [, s] = t;
                    return r.position - s.position;
                  }),
              [c, h, p]
            );
          return (0, s.jsxs)(s.Fragment, {
            children: [
              (0, s.jsx)("div", {
                className: "space-y-5",
                children: f.map((e, t) => {
                  let [l, i] = e;
                  return (0, s.jsxs)(
                    "div",
                    {
                      children: [
                        0 === t
                          ? (0, s.jsxs)("div", {
                              className: "flex-[6] flex items-center pr-10 gap-2 my-3",
                              children: [
                                (0, s.jsxs)("div", {
                                  className: "flex w-[184px] items-center",
                                  children: [
                                    (0, s.jsx)("h3", { className: "text-sm font-medium text-gray-700 dark:text-gray-400", children: i.label }),
                                    (0, s.jsx)("button", {
                                      className: "ml-2 opacity-40",
                                      onClick: () => {
                                        a(l);
                                      },
                                      children: (0, s.jsx)("img", { src: o.HelpIcon, alt: "help", className: "h-[14px] w-[14px]" })
                                    })
                                  ]
                                }),
                                (0, s.jsx)("p", {
                                  className: "flex-[1] flex-shrink-0 dark:text-[#858585] text-gray-400 font-bold text-sm text-center",
                                  children: "TVL"
                                }),
                                (0, s.jsx)("p", {
                                  className: "flex-[1] flex-shrink-0 dark:text-[#858585] text-gray-400 font-bold text-sm text-center",
                                  children: "APR"
                                })
                              ]
                            })
                          : (0, s.jsxs)("div", {
                              className: "flex items-center",
                              children: [
                                (0, s.jsx)("h3", { className: "text-sm font-medium text-gray-700 dark:text-gray-300", children: i.label }),
                                (0, s.jsx)("button", {
                                  className: "ml-2 opacity-40",
                                  onClick: () => {
                                    a(l);
                                  },
                                  children: (0, s.jsx)("img", { src: o.HelpIcon, alt: "help", className: "h-[14px] w-[14px]" })
                                })
                              ]
                            }),
                        (0, s.jsx)(g, { dapps: h, products: p, categoryId: l, sortBy: r.sortBy })
                      ]
                    },
                    l
                  );
                })
              }),
              (0, s.jsxs)("div", {
                className: "mt-4",
                children: [
                  (0, s.jsx)("h4", { className: "text-gray-400 dark:text-gray-700 font-bold text-xs", children: "Disclaimer" }),
                  (0, s.jsx)("p", { className: "text-gray-400 dark:text-gray-700 text-[10px] mt-1", children: u })
                ]
              }),
              (0, s.jsx)(n.Z, {
                title: "Earn Section Help",
                isOpen: !!l,
                onClose: () => a(void 0),
                closeOnBackdropClick: !0,
                children: l
                  ? (0, s.jsxs)("div", {
                      className: "dark:bg-gray-900 bg-white-100 rounded-2xl flex flex-col justify-center p-4",
                      children: [
                        (0, s.jsx)("img", { src: d.TxFee, alt: "dollar icon", className: "h-12 w-12 filter grayscale opacity-50" }),
                        (0, s.jsxs)("h2", { className: "text-gray-900 dark:text-white-100 font-bold mt-4", children: ["What are ", c[l].label, "?"] }),
                        (0, s.jsx)("p", { className: "text-gray-500 dark:text-gray-400 text-sm mt-2", children: c[l].description })
                      ]
                    })
                  : null
              })
            ]
          });
        },
        j = e => {
          let { displaySettings: t } = e,
            r = (0, l.WfF)();
          return "loading" === r.status
            ? (0, s.jsxs)("div", {
                children: [
                  (0, s.jsxs)("div", {
                    children: [
                      (0, s.jsx)("div", { className: "inline-block !h-5 !w-20 rounded-md animate-pulse bg-gray-100 dark:bg-gray-900" }),
                      (0, s.jsxs)("div", {
                        className: "mt-2 rounded-2xl overflow-hidden",
                        children: [
                          (0, s.jsx)("div", { className: "h-11 w-full !m-0 rounded-t-2xl animate-pulse bg-gray-100 dark:bg-gray-900" }),
                          (0, s.jsx)("div", { className: "border-t border-t-gray-900 !m-0" }),
                          (0, s.jsx)("div", { className: "h-11 w-full !m-0 animate-pulse bg-gray-100 dark:bg-gray-900" }),
                          (0, s.jsx)("div", { className: "border-t border-t-gray-900 !m-0" }),
                          (0, s.jsx)("div", { className: "h-11 w-full !m-0 rounded-b-2xl animate-pulse bg-gray-100 dark:bg-gray-900" })
                        ]
                      })
                    ]
                  }),
                  (0, s.jsxs)("div", {
                    className: "mt-4",
                    children: [
                      (0, s.jsx)("div", { className: "inline-block !h-5 !w-20 rounded-md animate-pulse bg-gray-100 dark:bg-gray-900" }),
                      (0, s.jsxs)("div", {
                        className: "mt-2 rounded-2xl overflow-hidden",
                        children: [
                          (0, s.jsx)("div", { className: "h-11 w-full !m-0 rounded-t-2xl animate-pulse bg-gray-100 dark:bg-gray-900" }),
                          (0, s.jsx)("div", { className: "border-t border-t-gray-900 !m-0" }),
                          (0, s.jsx)("div", { className: "h-11 w-full !m-0 rounded-b-2xl animate-pulse bg-gray-100 dark:bg-gray-900" })
                        ]
                      })
                    ]
                  })
                ]
              })
            : "error" === r.status
              ? (0, s.jsx)(a._, { text: r.error.message, disableSentryCapture: !0 })
              : (0, s.jsx)(f, { data: r.data, displaySettings: t });
        };
    }
  }
]);
//# sourceMappingURL=5884.js.map
