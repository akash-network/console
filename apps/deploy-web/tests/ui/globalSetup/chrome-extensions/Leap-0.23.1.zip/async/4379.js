!(function () {
  try {
    var t = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
      e = new t.Error().stack;
    e &&
      ((t._sentryDebugIds = t._sentryDebugIds || {}),
      (t._sentryDebugIds[e] = "5bebf243-2947-4f76-a03e-4c1b53db96b8"),
      (t._sentryDebugIdIdentifier = "sentry-dbid-5bebf243-2947-4f76-a03e-4c1b53db96b8"));
  } catch (t) {}
})();
var _global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
_global.SENTRY_RELEASE = { id: "0.23.1" };
("use strict");
(self.webpackChunk_leap_cosmos_extension = self.webpackChunk_leap_cosmos_extension || []).push([
  ["4379"],
  {
    61533: function (t, e, n) {
      var r,
        a =
          (this && this.__extends) ||
          ((r = function (t, e) {
            return (r =
              Object.setPrototypeOf ||
              ({ __proto__: [] } instanceof Array &&
                function (t, e) {
                  t.__proto__ = e;
                }) ||
              function (t, e) {
                for (var n in e) Object.prototype.hasOwnProperty.call(e, n) && (t[n] = e[n]);
              })(t, e);
          }),
          function (t, e) {
            if ("function" != typeof e && null !== e) throw TypeError("Class extends value " + String(e) + " is not a constructor or null");
            function n() {
              this.constructor = t;
            }
            r(t, e), (t.prototype = null === e ? Object.create(e) : ((n.prototype = e.prototype), new n()));
          }),
        o =
          (this && this.__read) ||
          function (t, e) {
            var n = "function" == typeof Symbol && t[Symbol.iterator];
            if (!n) return t;
            var r,
              a,
              o = n.call(t),
              i = [];
            try {
              for (; (void 0 === e || e-- > 0) && !(r = o.next()).done; ) i.push(r.value);
            } catch (t) {
              a = { error: t };
            } finally {
              try {
                r && !r.done && (n = o.return) && n.call(o);
              } finally {
                if (a) throw a.error;
              }
            }
            return i;
          },
        i =
          (this && this.__spreadArray) ||
          function (t, e, n) {
            if (n || 2 == arguments.length)
              for (var r, a = 0, o = e.length; a < o; a++) (!r && a in e) || (r || (r = Array.prototype.slice.call(e, 0, a)), (r[a] = e[a]));
            return t.concat(r || Array.prototype.slice.call(e));
          },
        l =
          (this && this.__importDefault) ||
          function (t) {
            return t && t.__esModule ? t : { default: t };
          };
      Object.defineProperty(e, "__esModule", { value: !0 });
      var s = l(n(39273)),
        c = l(n(95524)),
        u = (function (t) {
          function e() {
            var e = t.apply(this, i([], o(arguments), !1)) || this;
            return (
              (e.tickAnimation = function () {
                e.confetti(
                  e.decorateOptions({
                    startVelocity: 30,
                    spread: 360,
                    ticks: 60,
                    zIndex: 0,
                    particleCount: 150,
                    origin: { x: (0, c.default)(0.1, 0.3), y: Math.random() - 0.2 }
                  })
                ),
                  e.confetti(
                    e.decorateOptions({
                      startVelocity: 30,
                      spread: 360,
                      ticks: 60,
                      zIndex: 0,
                      particleCount: 150,
                      origin: { x: (0, c.default)(0.7, 0.9), y: Math.random() - 0.2 }
                    })
                  );
              }),
              e
            );
          }
          return a(e, t), e;
        })(s.default);
      e.default = u;
    },
    39273: function (t, e) {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.default = function (t) {
          var e = t.confetti,
            n = t.decorateOptions,
            r = this;
          (this.interval = null),
            (this.shoot = function () {
              return r.tickAnimation();
            }),
            (this.run = function (t) {
              var e = t.speed,
                n = t.delay,
                a = t.duration;
              !r.interval &&
                setTimeout(
                  function () {
                    r.shoot(), (r.interval = setInterval(r.shoot, 1e3 / Math.min(e, 1e3))), a && setTimeout(r.pause, a);
                  },
                  void 0 === n ? 0 : n
                );
            }),
            (this.pause = function () {
              clearInterval(r.interval), (r.interval = null);
            }),
            (this.stop = function () {
              r.pause(), r.confetti.reset();
            }),
            (this.confetti = e),
            (this.decorateOptions = n);
        });
    },
    95524: function (t, e) {
      Object.defineProperty(e, "__esModule", { value: !0 }),
        (e.default = function (t, e) {
          return Math.random() * (e - t) + t;
        });
    },
    67861: function (t, e, n) {
      var r =
          (this && this.__assign) ||
          function () {
            return (r =
              Object.assign ||
              function (t) {
                for (var e, n = 1, r = arguments.length; n < r; n++)
                  for (var a in (e = arguments[n])) Object.prototype.hasOwnProperty.call(e, a) && (t[a] = e[a]);
                return t;
              }).apply(this, arguments);
          },
        a =
          (this && this.__createBinding) ||
          (Object.create
            ? function (t, e, n, r) {
                void 0 === r && (r = n);
                var a = Object.getOwnPropertyDescriptor(e, n);
                (!a || ("get" in a ? !e.__esModule : a.writable || a.configurable)) &&
                  (a = {
                    enumerable: !0,
                    get: function () {
                      return e[n];
                    }
                  }),
                  Object.defineProperty(t, r, a);
              }
            : function (t, e, n, r) {
                void 0 === r && (r = n), (t[r] = e[n]);
              }),
        o =
          (this && this.__setModuleDefault) ||
          (Object.create
            ? function (t, e) {
                Object.defineProperty(t, "default", { enumerable: !0, value: e });
              }
            : function (t, e) {
                t.default = e;
              }),
        i =
          (this && this.__importStar) ||
          function (t) {
            if (t && t.__esModule) return t;
            var e = {};
            if (null != t) for (var n in t) "default" !== n && Object.prototype.hasOwnProperty.call(t, n) && a(e, t, n);
            return o(e, t), e;
          },
        l =
          (this && this.__importDefault) ||
          function (t) {
            return t && t.__esModule ? t : { default: t };
          };
      Object.defineProperty(e, "__esModule", { value: !0 });
      var s = i(n(2784)),
        c = l(n(51931)),
        u = { resize: !0, useWorker: !1 },
        f = { position: "fixed", pointerEvents: "none", width: "100%", height: "100%", top: 0, left: 0 };
      e.default = function (t) {
        var e = t.style,
          n = t.className,
          a = t.width,
          o = t.height,
          i = t.globalOptions,
          l = t.onInit,
          h = (0, s.useRef)(null),
          d = (0, s.useRef)(null);
        return (
          (0, s.useEffect)(function () {
            if (h.current)
              return (
                (d.current = c.default.create(h.current, r(r({}, u), i))),
                null == l || l({ confetti: d.current }),
                function () {
                  var t;
                  null === (t = d.current) || void 0 === t || t.reset();
                }
              );
          }, []),
          s.default.createElement("canvas", { ref: h, style: e || n ? e : f, className: n, width: a, height: o })
        );
      };
    },
    43579: function (t, e, n) {
      var r =
          (this && this.__assign) ||
          function () {
            return (r =
              Object.assign ||
              function (t) {
                for (var e, n = 1, r = arguments.length; n < r; n++)
                  for (var a in (e = arguments[n])) Object.prototype.hasOwnProperty.call(e, a) && (t[a] = e[a]);
                return t;
              }).apply(this, arguments);
          },
        a =
          (this && this.__importDefault) ||
          function (t) {
            return t && t.__esModule ? t : { default: t };
          };
      Object.defineProperty(e, "__esModule", { value: !0 });
      var o = a(n(2784)),
        i = a(n(79640)),
        l = a(n(61533));
      e.default = function (t) {
        return o.default.createElement(i.default, r({ Conductor: l.default }, t));
      };
    },
    79640: function (t, e, n) {
      var r =
          (this && this.__assign) ||
          function () {
            return (r =
              Object.assign ||
              function (t) {
                for (var e, n = 1, r = arguments.length; n < r; n++)
                  for (var a in (e = arguments[n])) Object.prototype.hasOwnProperty.call(e, a) && (t[a] = e[a]);
                return t;
              }).apply(this, arguments);
          },
        a =
          (this && this.__createBinding) ||
          (Object.create
            ? function (t, e, n, r) {
                void 0 === r && (r = n);
                var a = Object.getOwnPropertyDescriptor(e, n);
                (!a || ("get" in a ? !e.__esModule : a.writable || a.configurable)) &&
                  (a = {
                    enumerable: !0,
                    get: function () {
                      return e[n];
                    }
                  }),
                  Object.defineProperty(t, r, a);
              }
            : function (t, e, n, r) {
                void 0 === r && (r = n), (t[r] = e[n]);
              }),
        o =
          (this && this.__setModuleDefault) ||
          (Object.create
            ? function (t, e) {
                Object.defineProperty(t, "default", { enumerable: !0, value: e });
              }
            : function (t, e) {
                t.default = e;
              }),
        i =
          (this && this.__importStar) ||
          function (t) {
            if (t && t.__esModule) return t;
            var e = {};
            if (null != t) for (var n in t) "default" !== n && Object.prototype.hasOwnProperty.call(t, n) && a(e, t, n);
            return o(e, t), e;
          },
        l =
          (this && this.__rest) ||
          function (t, e) {
            var n = {};
            for (var r in t) Object.prototype.hasOwnProperty.call(t, r) && 0 > e.indexOf(r) && (n[r] = t[r]);
            if (null != t && "function" == typeof Object.getOwnPropertySymbols)
              for (var a = 0, r = Object.getOwnPropertySymbols(t); a < r.length; a++)
                0 > e.indexOf(r[a]) && Object.prototype.propertyIsEnumerable.call(t, r[a]) && (n[r[a]] = t[r[a]]);
            return n;
          },
        s =
          (this && this.__read) ||
          function (t, e) {
            var n = "function" == typeof Symbol && t[Symbol.iterator];
            if (!n) return t;
            var r,
              a,
              o = n.call(t),
              i = [];
            try {
              for (; (void 0 === e || e-- > 0) && !(r = o.next()).done; ) i.push(r.value);
            } catch (t) {
              a = { error: t };
            } finally {
              try {
                r && !r.done && (n = o.return) && n.call(o);
              } finally {
                if (a) throw a.error;
              }
            }
            return i;
          },
        c =
          (this && this.__importDefault) ||
          function (t) {
            return t && t.__esModule ? t : { default: t };
          };
      Object.defineProperty(e, "__esModule", { value: !0 });
      var u = i(n(2784)),
        f = c(n(67861)),
        h = function (t) {
          return t;
        };
      e.default = function (t) {
        var e = t.decorateOptions,
          n = void 0 === e ? h : e,
          a = t.Conductor,
          o = t.autorun,
          i = t.onInit,
          c = l(t, ["decorateOptions", "Conductor", "autorun", "onInit"]),
          d = s((0, u.useState)(), 2),
          p = d[0],
          b = d[1],
          m = (0, u.useCallback)(function (t) {
            var e = t.confetti;
            b(function () {
              return e;
            });
          }, []);
        return (
          (0, u.useEffect)(
            function () {
              if (p) {
                var t = new a({ confetti: p, decorateOptions: n });
                return o && t.run(o), null == i || i({ confetti: p, conductor: t }), t.stop;
              }
            },
            [p]
          ),
          u.default.createElement(f.default, r({ onInit: m }, c))
        );
      };
    },
    51931: function (t, e, n) {
      n.r(e), n.d(e, { create: () => o, default: () => a });
      var r = {};
      !(function t(e, n, r, a) {
        var o,
          i,
          l,
          s,
          c,
          u,
          f,
          h,
          d,
          p,
          b,
          m = !!(
            e.Worker &&
            e.Blob &&
            e.Promise &&
            e.OffscreenCanvas &&
            e.OffscreenCanvasRenderingContext2D &&
            e.HTMLCanvasElement &&
            e.HTMLCanvasElement.prototype.transferControlToOffscreen &&
            e.URL &&
            e.URL.createObjectURL
          ),
          y = "function" == typeof Path2D && "function" == typeof DOMMatrix;
        function g() {}
        function v(t) {
          var r = n.exports.Promise,
            a = void 0 !== r ? r : e.Promise;
          return "function" == typeof a ? new a(t) : (t(g, g), null);
        }
        var M =
            ((o = (function () {
              if (!e.OffscreenCanvas) return !1;
              var t = new OffscreenCanvas(1, 1),
                n = t.getContext("2d");
              n.fillRect(0, 0, 1, 1);
              var r = t.transferToImageBitmap();
              try {
                n.createPattern(r, "no-repeat");
              } catch (t) {
                return !1;
              }
              return !0;
            })()),
            (i = new Map()),
            {
              transform: function (t) {
                if (o) return t;
                if (i.has(t)) return i.get(t);
                var e = new OffscreenCanvas(t.width, t.height);
                return e.getContext("2d").drawImage(t, 0, 0), i.set(t, e), e;
              },
              clear: function () {
                i.clear();
              }
            }),
          w =
            ((c = Math.floor(1e3 / 60)),
            (u = {}),
            (f = 0),
            "function" == typeof requestAnimationFrame && "function" == typeof cancelAnimationFrame
              ? ((l = function (t) {
                  var e = Math.random();
                  return (
                    (u[e] = requestAnimationFrame(function n(r) {
                      f === r || f + c - 1 < r ? ((f = r), delete u[e], t()) : (u[e] = requestAnimationFrame(n));
                    })),
                    e
                  );
                }),
                (s = function (t) {
                  u[t] && cancelAnimationFrame(u[t]);
                }))
              : ((l = function (t) {
                  return setTimeout(t, c);
                }),
                (s = function (t) {
                  return clearTimeout(t);
                })),
            { frame: l, cancel: s }),
          _ =
            ((p = {}),
            function () {
              if (h) return h;
              if (!r && m) {
                var e = [
                  "var CONFETTI, SIZE = {}, module = {};",
                  "(" + t.toString() + ")(this, module, true, SIZE);",
                  "onmessage = function(msg) {",
                  "  if (msg.data.options) {",
                  "    CONFETTI(msg.data.options).then(function () {",
                  "      if (msg.data.callback) {",
                  "        postMessage({ callback: msg.data.callback });",
                  "      }",
                  "    });",
                  "  } else if (msg.data.reset) {",
                  "    CONFETTI && CONFETTI.reset();",
                  "  } else if (msg.data.resize) {",
                  "    SIZE.width = msg.data.resize.width;",
                  "    SIZE.height = msg.data.resize.height;",
                  "  } else if (msg.data.canvas) {",
                  "    SIZE.width = msg.data.canvas.width;",
                  "    SIZE.height = msg.data.canvas.height;",
                  "    CONFETTI = module.exports.create(msg.data.canvas);",
                  "  }",
                  "}"
                ].join("\n");
                try {
                  h = new Worker(URL.createObjectURL(new Blob([e])));
                } catch (t) {
                  return "function" == typeof console.warn && console.warn("\uD83C\uDF8A Could not load worker", t), null;
                }
                !(function (t) {
                  function e(e, n) {
                    t.postMessage({ options: e || {}, callback: n });
                  }
                  (t.init = function (e) {
                    var n = e.transferControlToOffscreen();
                    t.postMessage({ canvas: n }, [n]);
                  }),
                    (t.fire = function (n, r, a) {
                      if (d) return e(n, null), d;
                      var o = Math.random().toString(36).slice(2);
                      return (d = v(function (r) {
                        function i(e) {
                          e.data.callback === o && (delete p[o], t.removeEventListener("message", i), (d = null), M.clear(), a(), r());
                        }
                        t.addEventListener("message", i), e(n, o), (p[o] = i.bind(null, { data: { callback: o } }));
                      }));
                    }),
                    (t.reset = function () {
                      for (var e in (t.postMessage({ reset: !0 }), p)) p[e](), delete p[e];
                    });
                })(h);
              }
              return h;
            }),
          x = {
            particleCount: 50,
            angle: 90,
            spread: 45,
            startVelocity: 45,
            decay: 0.9,
            gravity: 1,
            drift: 0,
            ticks: 200,
            x: 0.5,
            y: 0.5,
            shapes: ["square", "circle"],
            zIndex: 100,
            colors: ["#26ccff", "#a25afd", "#ff5e7e", "#88ff5a", "#fcff42", "#ffa62d", "#ff36ff"],
            disableForReducedMotion: !1,
            scalar: 1
          };
        function O(t, e, n) {
          var r, a;
          return (a = t && null != t[e] ? t[e] : x[e]), n ? n(a) : a;
        }
        function P(t) {
          return t < 0 ? 0 : Math.floor(t);
        }
        function C(t) {
          return parseInt(t, 16);
        }
        function I(t) {
          return t.map(j);
        }
        function j(t) {
          var e = String(t).replace(/[^0-9a-f]/gi, "");
          return e.length < 6 && (e = e[0] + e[0] + e[1] + e[1] + e[2] + e[2]), { r: C(e.substring(0, 2)), g: C(e.substring(2, 4)), b: C(e.substring(4, 6)) };
        }
        function E(t) {
          (t.width = document.documentElement.clientWidth), (t.height = document.documentElement.clientHeight);
        }
        function S(t) {
          var e = t.getBoundingClientRect();
          (t.width = e.width), (t.height = e.height);
        }
        function T(t, n) {
          var o,
            i = !t,
            l = !!O(n || {}, "resize"),
            s = !1,
            c = O(n, "disableForReducedMotion", Boolean),
            u = m && O(n || {}, "useWorker") ? _() : null,
            f = i ? E : S,
            h = !!t && !!u && !!t.__confetti_initialized,
            d = "function" == typeof matchMedia && matchMedia("(prefers-reduced-motion)").matches;
          function p(n) {
            var p,
              b = c || O(n, "disableForReducedMotion", Boolean),
              m = O(n, "zIndex", Number);
            if (b && d)
              return v(function (t) {
                t();
              });
            i && o
              ? (t = o.canvas)
              : i &&
                !t &&
                (((p = document.createElement("canvas")).style.position = "fixed"),
                (p.style.top = "0px"),
                (p.style.left = "0px"),
                (p.style.pointerEvents = "none"),
                (p.style.zIndex = m),
                (t = p),
                document.body.appendChild(t)),
              l && !h && f(t);
            var g = { width: t.width, height: t.height };
            function _() {
              if (u) {
                var e = {
                  getBoundingClientRect: function () {
                    if (!i) return t.getBoundingClientRect();
                  }
                };
                f(e), u.postMessage({ resize: { width: e.width, height: e.height } });
                return;
              }
              g.width = g.height = null;
            }
            function x() {
              (o = null),
                l && ((s = !1), e.removeEventListener("resize", _)),
                i && t && (document.body.contains(t) && document.body.removeChild(t), (t = null), (h = !1));
            }
            return (u && !h && u.init(t), (h = !0), u && (t.__confetti_initialized = !0), l && !s && ((s = !0), e.addEventListener("resize", _, !1)), u)
              ? u.fire(n, g, x)
              : (function (e, n, i) {
                  for (
                    var l,
                      s,
                      c,
                      u,
                      h,
                      d,
                      p,
                      b = O(e, "particleCount", P),
                      m = O(e, "angle", Number),
                      g = O(e, "spread", Number),
                      _ = O(e, "startVelocity", Number),
                      x = O(e, "decay", Number),
                      C = O(e, "gravity", Number),
                      j = O(e, "drift", Number),
                      E = O(e, "colors", I),
                      S = O(e, "ticks", Number),
                      T = O(e, "shapes"),
                      k = O(e, "scalar"),
                      D = !!O(e, "flat"),
                      A = (((l = O(e, "origin", Object)).x = O(l, "x", Number)), (l.y = O(l, "y", Number)), l),
                      B = b,
                      R = [],
                      F = t.width * A.x,
                      N = t.height * A.y;
                    B--;

                  )
                    R.push(
                      (function (t) {
                        var e = t.angle * (Math.PI / 180),
                          n = t.spread * (Math.PI / 180);
                        return {
                          x: t.x,
                          y: t.y,
                          wobble: 10 * Math.random(),
                          wobbleSpeed: Math.min(0.11, 0.1 * Math.random() + 0.05),
                          velocity: 0.5 * t.startVelocity + Math.random() * t.startVelocity,
                          angle2D: -e + (0.5 * n - Math.random() * n),
                          tiltAngle: (0.5 * Math.random() + 0.25) * Math.PI,
                          color: t.color,
                          shape: t.shape,
                          tick: 0,
                          totalTicks: t.ticks,
                          decay: t.decay,
                          drift: t.drift,
                          random: Math.random() + 2,
                          tiltSin: 0,
                          tiltCos: 0,
                          wobbleX: 0,
                          wobbleY: 0,
                          gravity: 3 * t.gravity,
                          ovalScalar: 0.6,
                          scalar: t.scalar,
                          flat: t.flat
                        };
                      })({
                        x: F,
                        y: N,
                        angle: m,
                        spread: g,
                        startVelocity: _,
                        color: E[B % E.length],
                        shape: T[Math.floor(Math.random() * (T.length - 0)) + 0],
                        ticks: S,
                        decay: x,
                        gravity: C,
                        drift: j,
                        scalar: k,
                        flat: D
                      })
                    );
                  return o
                    ? o.addFettis(R)
                    : ((s = t),
                      (h = R.slice()),
                      (d = s.getContext("2d")),
                      (p = v(function (t) {
                        function e() {
                          (c = u = null), d.clearRect(0, 0, n.width, n.height), M.clear(), i(), t();
                        }
                        (c = w.frame(function t() {
                          r && (n.width !== a.width || n.height !== a.height) && ((n.width = s.width = a.width), (n.height = s.height = a.height)),
                            n.width || n.height || (f(s), (n.width = s.width), (n.height = s.height)),
                            d.clearRect(0, 0, n.width, n.height),
                            (h = h.filter(function (t) {
                              return (function (t, e) {
                                (e.x += Math.cos(e.angle2D) * e.velocity + e.drift),
                                  (e.y += Math.sin(e.angle2D) * e.velocity + e.gravity),
                                  (e.velocity *= e.decay),
                                  e.flat
                                    ? ((e.wobble = 0),
                                      (e.wobbleX = e.x + 10 * e.scalar),
                                      (e.wobbleY = e.y + 10 * e.scalar),
                                      (e.tiltSin = 0),
                                      (e.tiltCos = 0),
                                      (e.random = 1))
                                    : ((e.wobble += e.wobbleSpeed),
                                      (e.wobbleX = e.x + 10 * e.scalar * Math.cos(e.wobble)),
                                      (e.wobbleY = e.y + 10 * e.scalar * Math.sin(e.wobble)),
                                      (e.tiltAngle += 0.1),
                                      (e.tiltSin = Math.sin(e.tiltAngle)),
                                      (e.tiltCos = Math.cos(e.tiltAngle)),
                                      (e.random = Math.random() + 2));
                                var n,
                                  r,
                                  a,
                                  o,
                                  i,
                                  l,
                                  s,
                                  c,
                                  u,
                                  f,
                                  h,
                                  d,
                                  p,
                                  b,
                                  m,
                                  g,
                                  v = e.tick++ / e.totalTicks,
                                  w = e.x + e.random * e.tiltCos,
                                  _ = e.y + e.random * e.tiltSin,
                                  x = e.wobbleX + e.random * e.tiltCos,
                                  O = e.wobbleY + e.random * e.tiltSin;
                                if (
                                  ((t.fillStyle = "rgba(" + e.color.r + ", " + e.color.g + ", " + e.color.b + ", " + (1 - v) + ")"),
                                  t.beginPath(),
                                  y && "path" === e.shape.type && "string" == typeof e.shape.path && Array.isArray(e.shape.matrix))
                                ) {
                                  t.fill(
                                    ((n = e.shape.path),
                                    (r = e.shape.matrix),
                                    (a = e.x),
                                    (o = e.y),
                                    (i = 0.1 * Math.abs(x - w)),
                                    (l = 0.1 * Math.abs(O - _)),
                                    (s = (Math.PI / 10) * e.wobble),
                                    (c = new Path2D(n)),
                                    (u = new Path2D()).addPath(c, new DOMMatrix(r)),
                                    (f = new Path2D()).addPath(u, new DOMMatrix([Math.cos(s) * i, Math.sin(s) * i, -Math.sin(s) * l, Math.cos(s) * l, a, o])),
                                    f)
                                  );
                                } else if ("bitmap" === e.shape.type) {
                                  var P = (Math.PI / 10) * e.wobble,
                                    C = 0.1 * Math.abs(x - w),
                                    I = 0.1 * Math.abs(O - _),
                                    j = e.shape.bitmap.width * e.scalar,
                                    E = e.shape.bitmap.height * e.scalar,
                                    S = new DOMMatrix([Math.cos(P) * C, Math.sin(P) * C, -Math.sin(P) * I, Math.cos(P) * I, e.x, e.y]);
                                  S.multiplySelf(new DOMMatrix(e.shape.matrix));
                                  var T = t.createPattern(M.transform(e.shape.bitmap), "no-repeat");
                                  T.setTransform(S),
                                    (t.globalAlpha = 1 - v),
                                    (t.fillStyle = T),
                                    t.fillRect(e.x - j / 2, e.y - E / 2, j, E),
                                    (t.globalAlpha = 1);
                                } else if ("circle" === e.shape)
                                  t.ellipse
                                    ? t.ellipse(
                                        e.x,
                                        e.y,
                                        Math.abs(x - w) * e.ovalScalar,
                                        Math.abs(O - _) * e.ovalScalar,
                                        (Math.PI / 10) * e.wobble,
                                        0,
                                        2 * Math.PI
                                      )
                                    : ((h = e.x),
                                      (d = e.y),
                                      (p = Math.abs(x - w) * e.ovalScalar),
                                      (b = Math.abs(O - _) * e.ovalScalar),
                                      (m = (Math.PI / 10) * e.wobble),
                                      (g = 2 * Math.PI),
                                      t.save(),
                                      t.translate(h, d),
                                      t.rotate(m),
                                      t.scale(p, b),
                                      t.arc(0, 0, 1, 0, g, void 0),
                                      t.restore());
                                else if ("star" === e.shape)
                                  for (var k = (Math.PI / 2) * 3, D = 4 * e.scalar, A = 8 * e.scalar, B = e.x, R = e.y, F = 5, N = Math.PI / 5; F--; )
                                    (B = e.x + Math.cos(k) * A),
                                      (R = e.y + Math.sin(k) * A),
                                      t.lineTo(B, R),
                                      (k += N),
                                      (B = e.x + Math.cos(k) * D),
                                      (R = e.y + Math.sin(k) * D),
                                      t.lineTo(B, R),
                                      (k += N);
                                else
                                  t.moveTo(Math.floor(e.x), Math.floor(e.y)),
                                    t.lineTo(Math.floor(e.wobbleX), Math.floor(_)),
                                    t.lineTo(Math.floor(x), Math.floor(O)),
                                    t.lineTo(Math.floor(w), Math.floor(e.wobbleY));
                                return t.closePath(), t.fill(), e.tick < e.totalTicks;
                              })(d, t);
                            })).length
                              ? (c = w.frame(t))
                              : e();
                        })),
                          (u = e);
                      })),
                      (o = {
                        addFettis: function (t) {
                          return (h = h.concat(t)), p;
                        },
                        canvas: s,
                        promise: p,
                        reset: function () {
                          c && w.cancel(c), u && u();
                        }
                      }).promise);
                })(n, g, x);
          }
          return (
            (p.reset = function () {
              u && u.reset(), o && o.reset();
            }),
            p
          );
        }
        function k() {
          return b || (b = T(null, { useWorker: !0, resize: !0 })), b;
        }
        (n.exports = function () {
          return k().apply(this, arguments);
        }),
          (n.exports.reset = function () {
            k().reset();
          }),
          (n.exports.create = T),
          (n.exports.shapeFromPath = function (t) {
            if (!y) throw Error("path confetti are not supported in this browser");
            "string" == typeof t ? (r = t) : ((r = t.path), (a = t.matrix));
            var e = new Path2D(r),
              n = document.createElement("canvas").getContext("2d");
            if (!a) {
              for (var r, a, o, i, l = 1e3, s = 1e3, c = 0, u = 0, f = 0; f < 1e3; f += 2)
                for (var h = 0; h < 1e3; h += 2)
                  n.isPointInPath(e, f, h, "nonzero") && ((l = Math.min(l, f)), (s = Math.min(s, h)), (c = Math.max(c, f)), (u = Math.max(u, h)));
              o = c - l;
              var d = Math.min(10 / o, 10 / (i = u - s));
              a = [d, 0, 0, d, -Math.round(o / 2 + l) * d, -Math.round(i / 2 + s) * d];
            }
            return { type: "path", path: r, matrix: a };
          }),
          (n.exports.shapeFromText = function (t) {
            var e,
              n = 1,
              r = "#000000",
              a =
                '"Apple Color Emoji", "Segoe UI Emoji", "Segoe UI Symbol", "Noto Color Emoji", "EmojiOne Color", "Android Emoji", "Twemoji Mozilla", "system emoji", sans-serif';
            "string" == typeof t
              ? (e = t)
              : ((e = t.text), (n = "scalar" in t ? t.scalar : n), (a = "fontFamily" in t ? t.fontFamily : a), (r = "color" in t ? t.color : r));
            var o = 10 * n,
              i = "" + o + "px " + a,
              l = new OffscreenCanvas(o, o),
              s = l.getContext("2d");
            s.font = i;
            var c = s.measureText(e),
              u = Math.ceil(c.actualBoundingBoxRight + c.actualBoundingBoxLeft),
              f = Math.ceil(c.actualBoundingBoxAscent + c.actualBoundingBoxDescent),
              h = c.actualBoundingBoxLeft + 2,
              d = c.actualBoundingBoxAscent + 2;
            (u += 4), (f += 4), ((s = (l = new OffscreenCanvas(u, f)).getContext("2d")).font = i), (s.fillStyle = r), s.fillText(e, h, d);
            var p = 1 / n;
            return { type: "bitmap", bitmap: l.transferToImageBitmap(), matrix: [p, 0, 0, p, (-u * p) / 2, (-f * p) / 2] };
          });
      })(
        (function () {
          return "undefined" != typeof window ? window : "undefined" != typeof self ? self : this || {};
        })(),
        r,
        !1
      );
      let a = r.exports;
      var o = r.exports.create;
    }
  }
]);
//# sourceMappingURL=4379.js.map
