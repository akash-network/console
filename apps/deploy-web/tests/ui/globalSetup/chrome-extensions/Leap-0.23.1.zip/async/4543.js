!(function () {
  try {
    var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
      a = new e.Error().stack;
    a &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[a] = "d9a24257-8cd5-4972-be82-a1b32af9e970"),
      (e._sentryDebugIdIdentifier = "sentry-dbid-d9a24257-8cd5-4972-be82-a1b32af9e970"));
  } catch (e) {}
})();
var _global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
_global.SENTRY_RELEASE = { id: "0.23.1" };
("use strict");
(self.webpackChunk_leap_cosmos_extension = self.webpackChunk_leap_cosmos_extension || []).push([
  ["4543"],
  {
    5147: function (e, a, t) {
      t.a(e, async function (e, r) {
        try {
          t.r(a), t.d(a, { default: () => f });
          var l = t(52322),
            n = t(43166),
            o = t(46906),
            s = t(91486),
            c = t(65027),
            d = t(75958);
          t(2784);
          var i = t(10289),
            u = e([c]);
          c = (u.then ? (await u)() : u)[0];
          let f = (0, d.Pi)(() => {
            let e = (0, i.s0)(),
              { removeAll: a } = c.w.useRemoveWallet();
            return (0, l.jsxs)("div", {
              className: "p-5 flex flex-col h-full justify-center",
              children: [
                (0, l.jsx)("nav", {
                  children: (0, l.jsxs)("button", {
                    type: "button",
                    onClick: () => e("/"),
                    className: "p-2 rounded-full text-muted-foreground hover:text-foreground",
                    children: [(0, l.jsx)(n.X, { className: "size-5" }), (0, l.jsx)("span", { className: "sr-only", children: "Go back" })]
                  })
                }),
                (0, l.jsxs)("header", {
                  className: "flex flex-col gap-5 mb-5",
                  children: [
                    (0, l.jsx)("div", {
                      className: "bg-secondary-200 rounded-full size-20 mx-auto flex items-center justify-center",
                      children: (0, l.jsx)(o.H, { size: 32, className: "text-secondary-800" })
                    }),
                    (0, l.jsx)("span", { className: "font-bold text-xl text-center", children: "Forgot your password?" })
                  ]
                }),
                (0, l.jsxs)("div", {
                  className: "flex flex-col gap-4 mt-2",
                  children: [
                    (0, l.jsx)("span", {
                      className: "text-secondary-foreground text-md",
                      children: "Clear your data and restore your wallet using your recovery phrase"
                    }),
                    (0, l.jsx)("span", {
                      className: "text-secondary-foreground text-md",
                      children: "We won't be able to recover your password as it's stored securely only on your computer."
                    }),
                    (0, l.jsx)("span", {
                      className: "text-secondary-foreground text-md",
                      children:
                        "To recover the wallet you will have to clear you data which will delete your current wallet and recovery phrase from this device, along with the list of accounts you've curated. After that you can restore you wallet using your recovery phrase"
                    })
                  ]
                }),
                (0, l.jsx)(s.zx, {
                  className: "w-full mt-auto",
                  onClick: () => {
                    a(!0), e("/onboardingImport");
                  },
                  "aria-label": "clear data and restore button in forgot password flow",
                  children: (0, l.jsx)("span", {
                    "aria-label": "clear data and restore button text in forgot password flow",
                    children: "Clear data and restore"
                  })
                })
              ]
            });
          });
          r();
        } catch (e) {
          r(e);
        }
      });
    },
    46906: function (e, a, t) {
      t.d(a, { H: () => y });
      var r = t(2784),
        l = t(6806);
      let n = new Map([
        [
          "bold",
          r.createElement(
            r.Fragment,
            null,
            r.createElement("path", {
              d: "M208,76H180V56A52,52,0,0,0,76,56V76H48A20,20,0,0,0,28,96V208a20,20,0,0,0,20,20H208a20,20,0,0,0,20-20V96A20,20,0,0,0,208,76ZM100,56a28,28,0,0,1,56,0V76H100ZM204,204H52V100H204Zm-60-52a16,16,0,1,1-16-16A16,16,0,0,1,144,152Z"
            })
          )
        ],
        [
          "duotone",
          r.createElement(
            r.Fragment,
            null,
            r.createElement("path", { d: "M216,96V208a8,8,0,0,1-8,8H48a8,8,0,0,1-8-8V96a8,8,0,0,1,8-8H208A8,8,0,0,1,216,96Z", opacity: "0.2" }),
            r.createElement("path", {
              d: "M208,80H176V56a48,48,0,0,0-96,0V80H48A16,16,0,0,0,32,96V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V96A16,16,0,0,0,208,80ZM96,56a32,32,0,0,1,64,0V80H96ZM208,208H48V96H208V208Zm-68-56a12,12,0,1,1-12-12A12,12,0,0,1,140,152Z"
            })
          )
        ],
        [
          "fill",
          r.createElement(
            r.Fragment,
            null,
            r.createElement("path", {
              d: "M208,80H176V56a48,48,0,0,0-96,0V80H48A16,16,0,0,0,32,96V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V96A16,16,0,0,0,208,80Zm-80,84a12,12,0,1,1,12-12A12,12,0,0,1,128,164Zm32-84H96V56a32,32,0,0,1,64,0Z"
            })
          )
        ],
        [
          "light",
          r.createElement(
            r.Fragment,
            null,
            r.createElement("path", {
              d: "M208,82H174V56a46,46,0,0,0-92,0V82H48A14,14,0,0,0,34,96V208a14,14,0,0,0,14,14H208a14,14,0,0,0,14-14V96A14,14,0,0,0,208,82ZM94,56a34,34,0,0,1,68,0V82H94ZM210,208a2,2,0,0,1-2,2H48a2,2,0,0,1-2-2V96a2,2,0,0,1,2-2H208a2,2,0,0,1,2,2Zm-72-56a10,10,0,1,1-10-10A10,10,0,0,1,138,152Z"
            })
          )
        ],
        [
          "regular",
          r.createElement(
            r.Fragment,
            null,
            r.createElement("path", {
              d: "M208,80H176V56a48,48,0,0,0-96,0V80H48A16,16,0,0,0,32,96V208a16,16,0,0,0,16,16H208a16,16,0,0,0,16-16V96A16,16,0,0,0,208,80ZM96,56a32,32,0,0,1,64,0V80H96ZM208,208H48V96H208V208Zm-68-56a12,12,0,1,1-12-12A12,12,0,0,1,140,152Z"
            })
          )
        ],
        [
          "thin",
          r.createElement(
            r.Fragment,
            null,
            r.createElement("path", {
              d: "M208,84H172V56a44,44,0,0,0-88,0V84H48A12,12,0,0,0,36,96V208a12,12,0,0,0,12,12H208a12,12,0,0,0,12-12V96A12,12,0,0,0,208,84ZM92,56a36,36,0,0,1,72,0V84H92ZM212,208a4,4,0,0,1-4,4H48a4,4,0,0,1-4-4V96a4,4,0,0,1,4-4H208a4,4,0,0,1,4,4Zm-76-56a8,8,0,1,1-8-8A8,8,0,0,1,136,152Z"
            })
          )
        ]
      ]);
      var o = Object.defineProperty,
        s = Object.defineProperties,
        c = Object.getOwnPropertyDescriptors,
        d = Object.getOwnPropertySymbols,
        i = Object.prototype.hasOwnProperty,
        u = Object.prototype.propertyIsEnumerable,
        f = (e, a, t) => (a in e ? o(e, a, { enumerable: !0, configurable: !0, writable: !0, value: t }) : (e[a] = t)),
        m = (e, a) => {
          for (var t in a || (a = {})) i.call(a, t) && f(e, t, a[t]);
          if (d) for (var t of d(a)) u.call(a, t) && f(e, t, a[t]);
          return e;
        },
        p = (e, a) => s(e, c(a));
      let y = (0, r.forwardRef)((e, a) => r.createElement(l.Z, p(m({ ref: a }, e), { weights: n })));
      y.displayName = "Lock";
    }
  }
]);
//# sourceMappingURL=4543.js.map
