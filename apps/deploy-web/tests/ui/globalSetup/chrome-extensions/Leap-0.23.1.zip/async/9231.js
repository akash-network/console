!(function () {
  try {
    var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "133f6b89-41fc-424c-ae19-c88a53acdb16"),
      (e._sentryDebugIdIdentifier = "sentry-dbid-133f6b89-41fc-424c-ae19-c88a53acdb16"));
  } catch (e) {}
})();
var _global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
_global.SENTRY_RELEASE = { id: "0.23.1" };
("use strict");
(self.webpackChunk_leap_cosmos_extension = self.webpackChunk_leap_cosmos_extension || []).push([
  ["9231"],
  {
    79215: function (e, t, n) {
      n.d(t, { og: () => f });
      var a = n(52322),
        i = n(26793),
        s = n(89187),
        o = n(16283),
        r = n(85027),
        l = n(86240),
        d = n(65953);
      n(2784);
      var c = n(70514),
        u = n(49409);
      let m = e => {
          let { activeIndex: t, setActiveIndex: n, limit: d } = e,
            { walletAvatar: u, walletName: m } = (0, l.v)();
          return (0, a.jsxs)(r.m, {
            className: "bg-secondary-50 border-b border-secondary-100",
            children: [
              (0, a.jsx)("div", { className: "w-[72px]" }),
              (0, a.jsx)(o.G2, { className: "bg-secondary-200", showWalletAvatar: !0, walletName: m, walletAvatar: u, handleDropdownClick: () => void 0 }),
              (0, a.jsx)("div", {
                className: "min-w-[72px]",
                children:
                  void 0 !== t &&
                  void 0 !== d &&
                  d > 1 &&
                  (0, a.jsxs)("div", {
                    className: "flex items-center rounded-full bg-secondary-200 p-2 justify-between",
                    children: [
                      (0, a.jsx)(i.W, {
                        size: 14,
                        className: (0, c.cn)("", { "text-muted-foreground": 0 === t, "text-foreground cursor-pointer": 0 !== t }),
                        onClick: () => {
                          n && void 0 !== t && t > 0 && n(t - 1);
                        }
                      }),
                      (0, a.jsxs)("p", { className: "text-sm font-bold text-foreground", children: [t + 1, "/", d] }),
                      (0, a.jsx)(s.T, {
                        size: 14,
                        className: (0, c.cn)("", { "text-muted-foreground": t === d - 1, "text-foreground cursor-pointer": t !== d - 1 }),
                        onClick: () => {
                          n && void 0 !== t && d && t < d - 1 && n(t + 1);
                        }
                      })
                    ]
                  })
              })
            ]
          });
        },
        g = e =>
          (0, a.jsxs)("div", {
            className: "flex items-center gap-5",
            children: [
              (0, a.jsx)("img", { src: e.logo, onError: (0, u._)(d.Globe), className: "size-[54px] rounded-full" }),
              (0, a.jsxs)("div", {
                className: "flex flex-col gap-[3px]",
                children: [
                  (0, a.jsx)("span", { className: "text-lg font-bold", children: e.title }),
                  (0, a.jsx)("span", { className: "text-xs text-muted-foreground", children: e.subTitle })
                ]
              })
            ]
          }),
        f = e =>
          (0, a.jsxs)(a.Fragment, {
            children: [
              (0, a.jsx)(m, { activeIndex: e.activeIndex, setActiveIndex: e.setActiveIndex, limit: e.limit }),
              (0, a.jsxs)("div", {
                className: (0, c.cn)(
                  "flex flex-col gap-6 mx-auto h-[calc(100%-165px)] w-full max-w-2xl box-border overflow-y-scroll pt-6 px-6 bg-secondary-50",
                  e.className
                ),
                children: [(0, a.jsx)(g, { ...e }), e.children]
              })
            ]
          });
    },
    57767: function (e, t, n) {
      n.d(t, { Z: () => r });
      var a = n(52322),
        i = n(14281);
      n(2784);
      var s = n(86376),
        o = n(69816);
      function r(e) {
        let { showLedgerPopup: t, onClose: n } = e;
        return (0, a.jsx)(i.Z, {
          isOpen: t,
          onClose: n,
          title: "Confirm on Ledger",
          children: (0, a.jsxs)("div", {
            className: "flex flex-col items-center",
            children: [
              (0, a.jsx)("div", { className: "my-10", children: (0, a.jsx)(s.Z, {}) }),
              (0, a.jsx)(o.Z, { size: "md", className: "font-bold mb-7", children: "Approve transaction on your hardware wallet" })
            ]
          })
        });
      }
    },
    74703: function (e, t, n) {
      n.d(t, { u: () => i });
      var a,
        i =
          (((a = {}).signResponse = "sign-response"),
          (a.signingPopupOpen = "signing-popup-open"),
          (a.signTransaction = "sign-transaction"),
          (a.signBitcoinResponse = "sign-bitcoin-response"),
          (a.signSeiEvmResponse = "sign-sei-evm-response"),
          a);
    },
    91128: function (e, t, n) {
      n.d(t, { R: () => i });
      var a = n(56594);
      function i(e, t) {
        return (0, a.calculateFee)(parseInt(e), t);
      }
    },
    34262: function (e, t, n) {
      n.a(e, async function (e, a) {
        try {
          n.r(t), n.d(t, { default: () => H });
          var i = n(52322),
            s = n(41172),
            o = n(15969),
            r = n(59458),
            l = n(7835),
            d = n(92642),
            c = n(72779),
            u = n.n(c),
            m = n(79215),
            g = n(86200),
            f = n(58885),
            v = n(57767),
            x = n(19623),
            p = n(69816),
            h = n(91486),
            b = n(74703),
            w = n(53108),
            y = n(79533),
            j = n(74229),
            N = n(76131),
            S = n(10706),
            D = n(78935),
            T = n(65027),
            k = n(75958),
            E = n(70734),
            C = n(2784),
            _ = n(10289),
            I = n(42799),
            P = n(39713),
            F = n(48346),
            M = n(46103),
            A = n(44818),
            L = n(48534),
            O = n(72565),
            R = n.n(O),
            B = n(99755),
            G = n(5531),
            U = n(98477),
            z = e([T, S, P, N, f, U, F]);
          [T, S, P, N, f, U, F] = z.then ? (await z)() : z;
          let Z = T.w.useGetWallet,
            W = T.w.useSuiSigner,
            $ = (0, k.Pi)(e => {
              let { data: t, chainId: n, rootBalanceStore: a, rootDenomsStore: c, activeChain: y } = e,
                T = (0, C.useRef)(!1),
                k = (0, C.useRef)(!1),
                I = (0, C.useRef)(!1),
                [F, O] = (0, C.useState)(!1),
                [z, $] = (0, C.useState)(null),
                [H] = (0, C.useState)(null),
                [Q, X] = (0, C.useState)(null),
                [q, J] = (0, C.useState)([]),
                [V, Y] = (0, C.useState)(0),
                K = (0, s.dco)(),
                ee = (0, s._ty)(y),
                et = (0, C.useMemo)(() => {
                  var e;
                  return parseInt((((null === (e = K[y]) || void 0 === e ? void 0 : e.DEFAULT_GAS_IBC) ?? o.N7W.DEFAULT_GAS_IBC) * ee).toString());
                }, [y, K, ee]),
                [en, ea] = (0, C.useState)(!1),
                [ei, es] = (0, C.useState)(0),
                [eo, er] = (0, C.useState)(""),
                [el, ed] = (0, C.useState)(!1),
                ec = ["sui-101", "sui-103"],
                eu = (0, s.rTu)(),
                em = W(),
                eg = Z(y),
                ef = (0, _.s0)(),
                { chains: ev } = (0, s._IL)(),
                ex = (0, S.Af)(),
                ep = (0, C.useMemo)(() => ("sui:testnet" === n ? "testnet" : "mainnet"), [n]),
                eh = c.allDenoms,
                eb = (0, f.e7)(eh, { activeChain: y }),
                ew = (0, s.bkk)(eh, y, ep),
                ey = s.rNU.useLogCosmosDappTx(),
                ej = (0, C.useRef)(!1),
                [eN, eS] = (0, C.useState)(null),
                [eD, eT] = (0, C.useState)(!1),
                ek = (0, s.FmJ)(),
                { lcdUrl: eE, rpcUrl: eC } = (0, s.U9i)(y, ep),
                e_ = P.zT.getStore(y, ep, !1),
                eI = null == e_ ? void 0 : e_.data,
                eP = (0, C.useRef)(null);
              (0, C.useEffect)(() => {
                !(async function () {
                  if (!eu || I.current) return;
                  let e = ["sui"].filter(e => {
                    var t, n, a, i;
                    let s = null == q ? void 0 : null === (n = q[0]) || void 0 === n ? void 0 : null === (t = n.addresses) || void 0 === t ? void 0 : t[e],
                      o = null == q ? void 0 : null === (i = q[0]) || void 0 === i ? void 0 : null === (a = i.pubKeys) || void 0 === a ? void 0 : a[e];
                    return (ev[e] && !s) || !o;
                  });
                  if (!(null == e ? void 0 : e.length)) return;
                  let t = {};
                  for await (let n of e) t[n] = ev[n];
                  let n = await ex(eu, e, "UPDATE", void 0, t);
                  I.current = !0;
                  let a = q.map(e => {
                    if (!n) return e;
                    let t = n[e.id];
                    return t || e;
                  });
                  J(a);
                })();
              }, []);
              let eF = (0, C.useMemo)(async () => {
                let e = await em(y);
                return await o.EW2.getSuiClient(e, ep);
              }, [y, em, ep]);
              (0, C.useEffect)(() => {
                !eN &&
                  eP.current &&
                  setTimeout(() => {
                    eP.current.scrollIntoView({ behavior: "smooth", block: "nearest" });
                  }, 10);
              }, [eN]),
                (0, C.useEffect)(() => {
                  a.loadBalances(y, ep);
                }, [y, ep]);
              let [eM, eA] = (0, C.useState)({ gasPrice: eb.gasPrice, option: s.j1p.LOW });
              (0, A.h)(null !== eu, "activeWallet is null");
              let {
                  shouldSubmit: eL,
                  isSignMessage: eO,
                  signOptions: eR
                } = (0, C.useMemo)(() => {
                  let e = null == t ? void 0 : t.submit,
                    n = null == t ? void 0 : t.isSignMessage,
                    a = null == t ? void 0 : t.signOptions;
                  return { shouldSubmit: e, isSignMessage: n, signOptions: a };
                }, [t]),
                {
                  allowSetFee: eB,
                  message: eG,
                  signDoc: eU,
                  fee: ez,
                  defaultFee: eZ
                } = (0, C.useMemo)(() => {
                  let {
                    allowSetFee: e,
                    updatedSignDoc: n,
                    updatedFee: a,
                    defaultFee: i
                  } = (0, B.E)({ signRequestData: t, gasPrice: eM.gasPrice, gasLimit: eo, isGasOptionSelected: ej.current, nativeFeeDenom: ew });
                  return { allowSetFee: e, message: "", signDoc: n, fee: a, defaultFee: i };
                }, [t, eM.gasPrice, eo, ew]),
                eW = null == t ? void 0 : t.origin,
                e$ = (0, D.G)(eW),
                eH = (0, j.a1)(),
                eQ = (0, C.useCallback)(() => {
                  setTimeout(() => {
                    a.refetchBalances(y, ep);
                  }, 3e3);
                }, [y, a, ep]),
                eX = (0, C.useCallback)(async () => {
                  T.current ||
                    k.current ||
                    ((T.current = !0),
                    await R().runtime.sendMessage({ type: b.u.signResponse, payload: { status: "error", data: "Transaction cancelled by the user." } }),
                    (0, L.oj)()
                      ? ef("/home")
                      : (await (0, o._vH)(100),
                        setTimeout(async () => {
                          window.close();
                        }, 10)));
                }, [ef]),
                eq = (0, C.useMemo)(() => {
                  if (eZ && (null == eZ ? void 0 : eZ.amount[0])) {
                    let { denom: e } = eZ.amount[0];
                    return e;
                  }
                  return eb.gasPrice.denom;
                }, [eZ, eb.gasPrice]),
                eJ = (0, C.useCallback)(async () => {
                  var e, t, a, i;
                  let r = eu.addresses[y];
                  if (!y || !eU || !r) return;
                  let l = await eF;
                  ed(!0);
                  try {
                    if (eO) {
                      let e = await l.signMessage(eU);
                      await (0, o._vH)(100);
                      try {
                        let t = (await R().storage.local.get(["CONNECTIONS"])).CONNECTIONS || [],
                          n = eW || "";
                        if (
                          !t.some(e => e.origin === n && e.walletIds.includes(eu.id) && e.chainIds.includes("sui-101") && e.chainIds.includes("sui-103")) &&
                          n
                        ) {
                          let e = [eu.id];
                          await (0, E.E)(["sui-101", "sui-103"], e, n);
                        }
                        R().runtime.sendMessage({ type: b.u.signResponse, payload: { status: "success", data: { signedTxData: e, activeAddress: r } } });
                      } catch (e) {
                        throw Error("Could not send transaction to the dApp");
                      }
                      ed(!1),
                        (0, L.oj)()
                          ? (eQ(), ef("/home"))
                          : setTimeout(async () => {
                              window.close();
                            }, 10);
                      return;
                    }
                    let a = await l.signTransaction(eU);
                    try {
                      await ey({
                        txHash: a.txHash,
                        txType: s.pb0.Dapp,
                        metadata: { ...ek, dapp_url: eW },
                        feeQuantity: V.toString(),
                        feeDenomination: (null == ez ? void 0 : null === (e = ez.amount[0]) || void 0 === e ? void 0 : e.denom) ?? "mist",
                        chain: y,
                        chainId: n,
                        address: r,
                        network: ep,
                        isSui: !0
                      });
                    } catch (e) {
                      (0, d.Tb)(e, {
                        tags: {
                          errorType: "sui_transaction_error",
                          source: "sign_transaction",
                          severity: "error",
                          errorName: e instanceof Error ? e.name : "SuiTransactionError",
                          transactionType: "sui_dapp_transaction"
                        },
                        fingerprint: ["sui_dapp_transaction", "sui_dapp_transaction_error"],
                        level: "error",
                        extra: {
                          feeQuantity: V.toString(),
                          feeDenomination: (null == ez ? void 0 : null === (t = ez.amount[0]) || void 0 === t ? void 0 : t.denom) ?? "mist",
                          chain: y,
                          chainId: n,
                          address: r,
                          network: ep,
                          isSui: !0,
                          appUrl: eW
                        },
                        contexts: { transaction: { type: "sui", chain: y, network: ep, errorMessage: e instanceof Error ? e.message : String(e) } }
                      });
                    }
                    if ((await (0, o._vH)(100), !eL)) {
                      try {
                        let e = (await R().storage.local.get(["CONNECTIONS"])).CONNECTIONS || [],
                          t = eW || "";
                        ec.every(async n => {
                          if (!e.some(e => e.origin === t && e.walletIds.includes(eu.id) && e.chainIds.includes(n)) && t) {
                            let e = [eu.id];
                            await (0, E.E)([n], e, t);
                          }
                        }),
                          R().runtime.sendMessage({ type: b.u.signResponse, payload: { status: "success", data: a } });
                      } catch {
                        throw Error("Could not send transaction to the dApp");
                      }
                      ed(!1),
                        (0, L.oj)()
                          ? (eQ(), ef("/home"))
                          : setTimeout(async () => {
                              window.close();
                            }, 10);
                      return;
                    }
                    let i = await l.broadcastTransaction(a.txnBytes, a.signature);
                    try {
                      let e = (await R().storage.local.get(["CONNECTIONS"])).CONNECTIONS || [],
                        t = eW || "";
                      if (!e.some(e => e.origin === t && e.walletIds.includes(eu.id) && e.chainIds.includes("sui-101")) && t) {
                        let e = [eu.id];
                        await (0, E.E)(["sui-101", "sui-103"], e, t);
                      }
                      R().runtime.sendMessage({ type: b.u.signResponse, payload: { status: "success", data: { broadcastedTxn: i, signedTxData: a } } });
                    } catch {
                      throw Error("Could not send transaction to the dApp");
                    }
                    ed(!1),
                      (0, L.oj)()
                        ? (eQ(), ef("/home"))
                        : setTimeout(async () => {
                            window.close();
                          }, 10);
                  } catch (e) {
                    (0, d.Tb)(e, {
                      tags: {
                        errorType: "sui_transaction_error",
                        source: "sign_transaction",
                        severity: "error",
                        errorName: e instanceof Error ? e.name : "SuiTransactionError",
                        transactionType: "sui_dapp_transaction"
                      },
                      fingerprint: ["sui_dapp_transaction", "sui_dapp_transaction_error"],
                      level: "error",
                      extra: {
                        feeQuantity: V.toString(),
                        feeDenomination: (null == ez ? void 0 : null === (a = ez.amount[0]) || void 0 === a ? void 0 : a.denom) ?? "mist",
                        chain: y,
                        chainId: n,
                        address: r,
                        network: ep,
                        isSui: !0,
                        appUrl: eW
                      },
                      contexts: { transaction: { chain: y, network: ep, errorMessage: e instanceof Error ? e.message : String(e) } }
                    }),
                      ed(!1),
                      $(
                        (null == e ? void 0 : null === (i = e.data) || void 0 === i ? void 0 : i.error_code) ??
                          (null == e ? void 0 : e.message) ??
                          "Unknown error"
                      ),
                      setTimeout(() => {
                        $(null);
                      }, 3e3);
                  }
                }, [eu.addresses, ep, y, eQ, eU, eg, eW, ez, ey, eX, eE]);
              (0, C.useEffect)(
                () => (
                  window.addEventListener("beforeunload", eX),
                  R().storage.local.remove(w.u1),
                  () => {
                    window.removeEventListener("beforeunload", eX);
                  }
                ),
                [eX]
              ),
                (0, C.useEffect)(() => {
                  (async function () {
                    if (!eO)
                      try {
                        ea(!0);
                        let e = et,
                          t = await em(y),
                          n = await o.EW2.getSuiClient(t, ep),
                          a = await n.simulateTransaction(eU, ep);
                        if (a.gasUnits) {
                          e = Number(a.gasUnits);
                          let t = Number(a.computationCost) + Number(a.storageCost) - Number(a.storageRebate) + Number(a.nonRefundableStorageFee);
                          Y(t / 1e9);
                        }
                        es(e);
                      } catch (e) {
                        es(et);
                      } finally {
                        ea(!1);
                      }
                  })();
                }, [y, null == eu ? void 0 : eu.pubKeys, et, eC]);
              let eV = (0, C.useMemo)(
                  () => !!(null == ez ? void 0 : ez.granter) || !!(null == ez ? void 0 : ez.payer) || !!(null == eR ? void 0 : eR.disableBalanceCheck),
                  [null == ez ? void 0 : ez.granter, null == ez ? void 0 : ez.payer, null == eR ? void 0 : eR.disableBalanceCheck]
                ),
                eY = !eq || !!z || !!Q || (!1 === eN && !eD) || en || el,
                eK = (0, C.useMemo)(
                  () => ({
                    page: "sign-sui-transaction",
                    queryStatus: eY ? "loading" : "success",
                    op: "signSuiTransactionPageApproveBtnLoad",
                    description: "Load time for sui sign transaction page's approve button",
                    terminateProps: {
                      maxDuration: 5e3,
                      logData: {
                        tags: {
                          isApproveBtnDisabled: eY,
                          dappFeeDenom: eq,
                          signingError: !!z,
                          gasPriceError: !!Q,
                          isFeesValid: !!eN,
                          highFeeAccepted: eD,
                          isSigning: el,
                          isLoadingGasLimit: en
                        },
                        context: { dappFeeDenom: eq, signingError: z, gasPriceError: Q }
                      }
                    }
                  }),
                  [eY, eq, z, Q, eN, eD, el, en]
                );
              return (
                (0, N.$)(eK),
                (0, i.jsxs)("div", {
                  className: "h-full",
                  children: [
                    (0, i.jsxs)(m.og, {
                      className: "bg-secondary-50",
                      subTitle: eW || "Unknown site",
                      logo: e$ || eH,
                      title: "Approve transaction",
                      children: [
                        eO
                          ? (0, i.jsx)("pre", {
                              className: u()(
                                "text-xs text-gray-900 dark:text-white-100 dark:bg-gray-900 bg-white-100 p-4 w-full overflow-x-auto rounded-2xl whitespace-pre-line break-words"
                              ),
                              children: (0, B.A)(eU, !0).signDoc
                            })
                          : (0, i.jsx)(f.ZP, {
                              className: "flex flex-col gap-6",
                              initialFeeDenom: eq,
                              gasLimit: eo || String(ei),
                              setGasLimit: e => er(e.toString()),
                              recommendedGasLimit: String(ei),
                              gasPriceOption: ej.current || eB ? eM : { ...eM, option: "" },
                              onGasPriceOptionChange: e => {
                                (ej.current = !0), eA(e);
                              },
                              error: Q,
                              setError: X,
                              considerGasAdjustment: !1,
                              disableBalanceCheck: eV,
                              fee: ez,
                              chain: y,
                              network: ep,
                              validateFee: !0,
                              onInvalidFees: (e, t) => {
                                try {
                                  !1 === t && eS(!1);
                                } catch (e) {
                                  var a, i, s, o;
                                  (0, d.Tb)(e, {
                                    extra: {
                                      feeQuantity: V.toString(),
                                      feeDenomination: (null == ez ? void 0 : null === (a = ez.amount[0]) || void 0 === a ? void 0 : a.denom) ?? "mist",
                                      chain: y,
                                      chainId: n,
                                      address: eu.addresses[y],
                                      network: ep,
                                      isSui: !0,
                                      appUrl: eW,
                                      level: "error",
                                      gasLimit: null == eo ? void 0 : eo.toString(),
                                      recommendedGasLimit: null == ei ? void 0 : ei.toString(),
                                      gasPriceOption: null == eM ? void 0 : eM.option,
                                      gasPriceAmount:
                                        null == eM
                                          ? void 0
                                          : null === (s = eM.gasPrice) || void 0 === s
                                            ? void 0
                                            : null === (i = s.amount) || void 0 === i
                                              ? void 0
                                              : i.toString(),
                                      gasPriceDenom: null == eM ? void 0 : null === (o = eM.gasPrice) || void 0 === o ? void 0 : o.denom,
                                      isLoadingGasLimit: en,
                                      hasUserTouchedFees: !!(null == ej ? void 0 : ej.current),
                                      isFeesValid: t,
                                      highFeeAccepted: eD
                                    }
                                  });
                                }
                              },
                              hasUserTouchedFees: !!(null == ej ? void 0 : ej.current),
                              notUpdateInitialGasPrice: !eB,
                              rootDenomsStore: c,
                              rootBalanceStore: a,
                              children: (0, i.jsx)(U.t, {
                                gasPriceError: Q,
                                txData: eU,
                                allowSetFee: eB,
                                staticFee: (0, i.jsx)(G.Z, {
                                  fee: ez,
                                  error: Q,
                                  setError: X,
                                  disableBalanceCheck: eV,
                                  rootBalanceStore: a,
                                  activeChain: y,
                                  selectedNetwork: ep,
                                  feeTokensList: eI
                                })
                              })
                            }),
                        z ?? H ? (0, i.jsx)(g._, { text: z ?? H ?? "", disableSentryCapture: !0 }) : null,
                        (0, i.jsx)(v.Z, {
                          showLedgerPopup: F,
                          onClose: () => {
                            O(!1);
                          }
                        })
                      ]
                    }),
                    (0, i.jsxs)("div", {
                      className: "flex flex-col p-6 bg-secondary-50 justify-center w-full gap-2 mt-auto [&>*]:flex-1 sticky bottom-0",
                      children: [
                        !1 === eN &&
                          (0, i.jsxs)("div", {
                            className: "flex flex-row items-center rounded-lg p-[4px]",
                            ref: eP,
                            children: [
                              (0, i.jsx)("div", {
                                className: "mr-2",
                                onClick: () => eT(!eD),
                                "aria-label": "sign sui transaction page high fee checkbox in sign sui transaction flow",
                                children: eD
                                  ? (0, i.jsx)(l.l, { size: 20, className: "cursor-pointer", color: M.w.green600 })
                                  : (0, i.jsx)(r.b, { size: 20, className: "text-green-600" })
                              }),
                              (0, i.jsx)(p.Z, {
                                size: "xs",
                                color: "dark:text-gray-400 text-gray-600",
                                children: "The selected fee amount is unusually high. I confirm and agree to proceed"
                              })
                            ]
                          }),
                        (0, i.jsxs)("div", {
                          className: "flex items-center justify-center w-full gap-3 mt-auto [&>*]:flex-1",
                          children: [
                            (0, i.jsx)(h.zx, {
                              variant: "mono",
                              onClick: eX,
                              "aria-label": "sign sui transaction page reject button in sign sui transaction flow",
                              children: (0, i.jsx)("span", {
                                "aria-label": "sign sui transaction page reject button text in sign sui transaction flow",
                                children: "Reject"
                              })
                            }),
                            (0, i.jsx)(h.zx, {
                              onClick: eJ,
                              disabled: eY,
                              className: `${eY ? "cursor-not-allowed opacity-50" : ""}`,
                              "aria-label": "sign sui transaction page approve button in sign sui transaction flow",
                              children: el
                                ? (0, i.jsx)(x.T, { color: "white" })
                                : (0, i.jsx)("span", {
                                    "aria-label": "sign sui transaction page approve button text in sign sui transaction flow",
                                    children: "Approve"
                                  })
                            })
                          ]
                        })
                      ]
                    })
                  ]
                })
              );
            }),
            H = (e => {
              let t = () => {
                let [t, n] = (0, C.useState)(),
                  [a, s] = (0, C.useState)(o.NOo),
                  [r, l] = (0, C.useState)(null),
                  [c, u] = (0, C.useState)(),
                  [m] = (0, C.useState)(null),
                  g = (0, _.s0)();
                (0, C.useEffect)(() => {
                  (0, y._d)().then(s).catch(d.Tb);
                }, []);
                let f = (e, t) => {
                  if (t.id === R().runtime.id && e.type === b.u.signTransaction) {
                    let t = e.payload,
                      i = t.chain ? t.chain : "sui-101",
                      s = i ? a["sui-101"] : void 0;
                    if (!s) {
                      R().runtime.sendMessage({ type: b.u.signResponse, payload: { status: "error", data: `Invalid chainId ${i}` } }),
                        (0, L.oj)()
                          ? g("/home")
                          : setTimeout(async () => {
                              window.close();
                            }, 10);
                      return;
                    }
                    n(s), u(i), l(t);
                  }
                };
                if (
                  ((0, C.useEffect)(
                    () => (
                      R().runtime.sendMessage({ type: b.u.signingPopupOpen }),
                      R().runtime.onMessage.addListener(f),
                      () => {
                        R().runtime.onMessage.removeListener(f);
                      }
                    ),
                    []
                  ),
                  t && r && c)
                )
                  return (0, i.jsx)(e, { data: r, chainId: c, activeChain: t, rootDenomsStore: I.gb, rootBalanceStore: F.jZ });
                if (m) {
                  var v;
                  let e = ((v = m.code), "no-data" === v ? "No Transaction Data" : "Something Went Wrong");
                  return (0, i.jsxs)("div", {
                    className: "h-full w-full flex flex-col gap-4 items-center justify-center",
                    children: [
                      (0, i.jsx)("h1", { className: "text-red-300 text-2xl font-bold px-4 text-center", children: e }),
                      (0, i.jsx)("p", { className: "text-black-100 dark:text-white-100 text-sm font-medium px-4 text-center", children: m.message }),
                      (0, i.jsx)("button", {
                        className: "mt-8 py-1 px-4 text-center text-sm font-medium dark:text-white-100 text-black-100 bg-indigo-300 rounded-full",
                        onClick: () => {
                          (0, L.oj)() ? g("/home") : window.close();
                        },
                        "aria-label": "sign sui transaction page close wallet button in sign sui transaction flow",
                        children: (0, i.jsx)("span", {
                          "aria-label": "sign sui transaction page close wallet button text in sign sui transaction flow",
                          children: "Close Wallet"
                        })
                      })
                    ]
                  });
                }
                return (0, i.jsx)("div", {
                  className: "h-full w-full flex flex-col gap-4 items-center justify-center",
                  children: (0, i.jsx)(x.T, { color: "white" })
                });
              };
              return (t.displayName = `withTxnSigningRequest(${e.displayName})`), t;
            })(C.memo($));
          a();
        } catch (e) {
          a(e);
        }
      });
    },
    5531: function (e, t, n) {
      n.d(t, { Z: () => g });
      var a = n(52322),
        i = n(41172),
        s = n(15969),
        o = n(60431),
        r = n(6391),
        l = n.n(r),
        d = n(6401),
        c = n(75958),
        u = n(2784);
      let m = (e, t) => {
          var n;
          let { amount: a } = e,
            i = (null === (n = a[0]) || void 0 === n ? void 0 : n.amount) ?? "",
            o = (0, s.t7o)(new (l())(i).toString(), t),
            r = o.toFormat(5, l().ROUND_DOWN),
            d = o.isLessThan("0.00001");
          return { amount: o, formattedAmount: d && !o.isEqualTo(0) ? "< 0.00001" : r };
        },
        g = (0, c.Pi)(e => {
          var t, n, s;
          let { fee: r, error: c, setError: g, disableBalanceCheck: f, rootBalanceStore: v, activeChain: x, selectedNetwork: p, feeTokensList: h } = e,
            b = (0, i.dco)(),
            [w] = (0, i.X$P)(),
            y = v.getSpendableBalancesForChain(x, p, void 0),
            j = v.getLoadingStatusForChain(x, p),
            N = (0, u.useMemo)(() => (j ? "loading" : "success"), [j]),
            S = (0, i.xxU)(),
            [D] = (0, d.nB)(),
            T = (0, u.useMemo)(() => {
              var e, t;
              let n = null == r ? void 0 : null === (e = r.amount[0]) || void 0 === e ? void 0 : e.denom,
                a = null == h ? void 0 : h.find(e => (e.ibcDenom ? e.ibcDenom === n : e.denom.coinMinimalDenom === n)),
                i =
                  null ===
                    (t = y.find(e => {
                      var t;
                      return (null == a ? void 0 : a.ibcDenom) || (null == e ? void 0 : e.ibcDenom)
                        ? (null == e ? void 0 : e.ibcDenom) === (null == a ? void 0 : a.ibcDenom)
                        : (null == e ? void 0 : e.coinMinimalDenom) ===
                            (null == a ? void 0 : null === (t = a.denom) || void 0 === t ? void 0 : t.coinMinimalDenom);
                    })) || void 0 === t
                    ? void 0
                    : t.amount;
              return { ...a, amount: i };
            }, [y, null == r ? void 0 : r.amount, h]),
            { data: k } = (0, o.useQuery)(
              ["fee-token-fiat-value", null == T ? void 0 : null === (t = T.denom) || void 0 === t ? void 0 : t.coinDenom],
              async () => {
                var e, t, n;
                return (0, i.knL)(
                  "1",
                  (null == T ? void 0 : null === (e = T.denom) || void 0 === e ? void 0 : e.coinGeckoId) ?? "",
                  null == T ? void 0 : null === (t = T.denom) || void 0 === t ? void 0 : t.chain,
                  i.r95[w].currencyPointer,
                  `${S}-${null == T ? void 0 : null === (n = T.denom) || void 0 === n ? void 0 : n.coinMinimalDenom}`
                );
              }
            ),
            E = (0, u.useMemo)(() => {
              var e;
              return r ? m(r, (null == T ? void 0 : null === (e = T.denom) || void 0 === e ? void 0 : e.coinDecimals) ?? 0) : null;
            }, [x, b, r, null == T ? void 0 : null === (n = T.denom) || void 0 === n ? void 0 : n.coinDecimals]);
          return (
            (0, u.useEffect)(() => {
              var e, t;
              let n = null == E ? void 0 : null === (e = E.amount) || void 0 === e ? void 0 : e.toString();
              !f &&
                n &&
                "loading" !== N &&
                (new (l())(n).isGreaterThan((null == T ? void 0 : T.amount) ?? 0)
                  ? g(`You don't have enough ${null == T ? void 0 : null === (t = T.denom) || void 0 === t ? void 0 : t.coinDenom} to pay the gas fee`)
                  : g(null));
            }, [T, E, N, f]),
            (0, a.jsx)("div", {
              className: "mt-3",
              children: E
                ? (0, a.jsx)("div", {
                    className: "rounded-lg bg-secondary-100 border border-secondary-200",
                    children: (0, a.jsxs)("div", {
                      className: "p-4",
                      children: [
                        (0, a.jsx)("div", {
                          className: "flex justify-between",
                          children: (0, a.jsx)("p", { className: "text-muted-foreground text-xs font-medium", children: "Gas Fees" })
                        }),
                        (0, a.jsxs)("p", {
                          className: "font-medium text-foreground text-sm mt-3 list-none ml-0",
                          children: [
                            E.formattedAmount,
                            " ",
                            null == T ? void 0 : null === (s = T.denom) || void 0 === s ? void 0 : s.coinDenom,
                            " ",
                            k ? D(new (l())((null == E ? void 0 : E.amount) ?? 0).multipliedBy(k)) : null
                          ]
                        }),
                        c ? (0, a.jsx)("p", { className: "font-medium text-destructive-400 text-sm mt-3 list-none ml-0", children: c }) : null
                      ]
                    })
                  })
                : null
            })
          );
        });
    },
    98477: function (e, t, n) {
      n.a(e, async function (e, a) {
        try {
          n.d(t, { t: () => p });
          var i = n(52322),
            s = n(58885),
            o = n(4370),
            r = n(14981),
            l = n(25053),
            d = n(2784),
            c = n(42799),
            u = n(48346),
            m = n(46338),
            g = n(43963),
            f = e([s, u]);
          [s, u] = f.then ? (await f)() : f;
          let v = [
              { id: "fees", label: "Fees" },
              { id: "details", label: "Details" }
            ],
            x = { transform: "translateX(0px) scaleX(0.161044)" },
            p = e => {
              let [t, n] = (0, d.useState)(v[0]);
              return (0, i.jsxs)(i.Fragment, {
                children: [
                  (0, i.jsx)("div", {
                    className: "border-b border-secondary-300",
                    children: (0, i.jsx)(l.z, {
                      buttons: v,
                      setSelectedTab: n,
                      selectedIndex: v.findIndex(e => {
                        let { id: n } = e;
                        return n === t.id;
                      }),
                      className: "gap-0.5",
                      buttonClassName: "px-3.5",
                      indicatorDefaultScale: x
                    })
                  }),
                  (0, i.jsx)("div", {
                    className: "flex flex-col gap-6",
                    children: (0, i.jsxs)(r.M, {
                      mode: "wait",
                      initial: !1,
                      children: [
                        "fees" === t.id &&
                          (0, i.jsx)(
                            o.E.div,
                            {
                              className: "flex flex-col gap-7",
                              transition: m._M,
                              variants: g.dJ,
                              initial: "exit",
                              animate: "animate",
                              exit: "exit",
                              children: e.allowSetFee
                                ? (0, i.jsxs)(i.Fragment, {
                                    children: [
                                      (0, i.jsx)(s.ZP.Selector, {}),
                                      (0, i.jsxs)("div", {
                                        className: "border border-border-bottom rounded-xl ",
                                        children: [
                                          (0, i.jsx)(s.ZP.AdditionalSettingsToggle, {}),
                                          (0, i.jsx)(s.ZP.AdditionalSettings, { showGasLimitWarning: !0, rootBalanceStore: u.jZ, rootDenomsStore: c.gb })
                                        ]
                                      }),
                                      !!e.gasPriceError &&
                                        (0, i.jsx)("p", { className: "text-destructive-100 text-sm font-medium px-1", children: e.gasPriceError }),
                                      " "
                                    ]
                                  })
                                : e.staticFee
                            },
                            "fees"
                          ),
                        "details" === t.id &&
                          (0, i.jsxs)("div", {
                            className: "flex flex-col gap-3 p-4 rounded-xl border border-secondary-200 bg-secondary-50",
                            children: [
                              (0, i.jsx)("span", { className: "text-muted-foreground text-xs font-medium", children: "Data" }),
                              (0, i.jsx)(
                                o.E.pre,
                                {
                                  transition: m._M,
                                  variants: g.dJ,
                                  initial: "enter",
                                  animate: "animate",
                                  exit: "enter",
                                  className: "text-xs w-full text-wrap break-words",
                                  children:
                                    "string" == typeof e.txData ? e.txData : JSON.stringify(e.txData, (e, t) => ("bigint" == typeof t ? t.toString() : t), 2)
                                },
                                "details"
                              )
                            ]
                          })
                      ]
                    })
                  })
                ]
              });
            };
          a();
        } catch (e) {
          a(e);
        }
      });
    },
    99755: function (e, t, n) {
      n.d(t, { A: () => l, E: () => d });
      var a = n(56594),
        i = n(15969),
        s = n(6391),
        o = n.n(s),
        r = n(91128);
      function l(e) {
        let t = arguments.length > 1 && void 0 !== arguments[1] && arguments[1],
          n = new Uint8Array(Object.values(e));
        return t ? { signDoc: new TextDecoder().decode(new Uint8Array(Object.values(e))), signOptions: {} } : { signDoc: n, signOptions: {} };
      }
      function d(e) {
        let { signRequestData: t, gasPrice: n, gasLimit: s, isGasOptionSelected: d, nativeFeeDenom: c } = e,
          { signOptions: u } = l(t.signDoc),
          m = (function (e, t, n, a, i) {
            let s = new (o())(t),
              l = (null == i ? void 0 : i.preferNoSetFee) && !a ? e : (0, r.R)(!s.isNaN() && s.isGreaterThan(0) ? s.toString() : e.gas, n);
            return (l.amount[0].amount = new (o())(l.amount[0].amount).toString()), l;
          })((0, a.calculateFee)(Number(1e6), i.DB5.fromString(`0${c.coinMinimalDenom}`)), s, n, d, u);
        return { updatedSignDoc: t.signDoc, updatedFee: m, allowSetFee: !1, defaultFee: m, defaultMemo: "" };
      }
    },
    25053: function (e, t, n) {
      n.d(t, { z: () => c });
      var a = n(52322),
        i = n(91486),
        s = n(65903),
        o = n(2784),
        r = n(70514);
      let l = (0, o.forwardRef)((e, t) =>
        (0, a.jsx)("button", {
          ref: t,
          className: (0, r.cn)(
            "text-sm font-medium text-foreground transition-colors capitalize pb-3.5 rounded-full",
            i.YV,
            e.active ? "text-accent-green" : "text-secondary-700 hover:text-foreground",
            e.className
          ),
          onClick: e.onClick,
          "aria-label": `tab button in stake v2 flow ${e.children}`,
          children: (0, a.jsx)("span", { "aria-label": `tab button text in stake v2 flow ${e.children}`, children: e.children })
        })
      );
      l.displayName = "TabButton";
      let d = { transform: "translateX(0px) scaleX(0.441654)" },
        c = e => {
          var t;
          let { setSelectedTab: n, selectedIndex: i, buttons: o, buttonClassName: c, className: u, indicatorDefaultScale: m } = e,
            { containerRef: g, indicatorRef: f, childRefs: v } = (0, s.r)({ navItems: o, activeLabel: null === (t = o[i]) || void 0 === t ? void 0 : t.label });
          return (0, a.jsxs)("div", {
            ref: g,
            className: (0, r.cn)("relative flex items-center isolate gap-7", u),
            children: [
              o.map((e, t) =>
                (0, a.jsx)(
                  l,
                  {
                    ref: e => v.current.set(t, e),
                    active: t === i,
                    onClick: () => n(e),
                    className: c,
                    "aria-label": `tab button in stake v2 flow ${e.label}`,
                    children: (0, a.jsx)("span", { "aria-label": `tab button text in stake v2 flow ${e.label}`, children: e.label })
                  },
                  e.id ?? e.label
                )
              ),
              (0, a.jsx)("div", {
                className:
                  "absolute bottom-0 h-0.5 origin-left scale-0 translate-x-3 transition-transform duration-200 w-full rounded-[50vmin/10vmin] z-10 bg-accent-green",
                ref: f,
                style: m ?? d
              })
            ]
          });
        };
      c.displayName = "TabSelectors";
    }
  }
]);
//# sourceMappingURL=9231.js.map
