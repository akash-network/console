!(function () {
  try {
    var e = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {},
      t = new e.Error().stack;
    t &&
      ((e._sentryDebugIds = e._sentryDebugIds || {}),
      (e._sentryDebugIds[t] = "9e60948f-7313-42cf-a1eb-4018fd7e7c9f"),
      (e._sentryDebugIdIdentifier = "sentry-dbid-9e60948f-7313-42cf-a1eb-4018fd7e7c9f"));
  } catch (e) {}
})();
var _global = "undefined" != typeof window ? window : "undefined" != typeof global ? global : "undefined" != typeof self ? self : {};
(_global.SENTRY_RELEASE = { id: "0.23.1" }),
  (() => {
    "use strict";
    var e = {},
      t = {};
    function r(n) {
      var o = t[n];
      if (void 0 !== o) return o.exports;
      var a = (t[n] = { id: n, loaded: !1, exports: {} });
      return e[n].call(a.exports, a, a.exports, r), (a.loaded = !0), a.exports;
    }
    (r.m = e),
      (() => {
        var e = "function" == typeof Symbol ? Symbol("webpack queues") : "__webpack_queues__",
          t = "function" == typeof Symbol ? Symbol("webpack exports") : "__webpack_exports__",
          n = "function" == typeof Symbol ? Symbol("webpack error") : "__webpack_error__",
          o = e => {
            e && e.d < 1 && ((e.d = 1), e.forEach(e => e.r--), e.forEach(e => (e.r-- ? e.r++ : e())));
          },
          a = r =>
            r.map(r => {
              if (null !== r && "object" == typeof r) {
                if (r[e]) return r;
                if (r.then) {
                  var a = [];
                  (a.d = 0),
                    r.then(
                      e => {
                        (i[t] = e), o(a);
                      },
                      e => {
                        (i[n] = e), o(a);
                      }
                    );
                  var i = {};
                  return (i[e] = e => e(a)), i;
                }
              }
              var s = {};
              return (s[e] = function () {}), (s[t] = r), s;
            });
        r.a = (r, i, s) => {
          s && ((u = []).d = -1);
          var u,
            f,
            c,
            l,
            d = new Set(),
            p = r.exports,
            b = new Promise((e, t) => {
              (l = t), (c = e);
            });
          (b[t] = p),
            (b[e] = e => {
              u && e(u), d.forEach(e), b.catch(function () {});
            }),
            (r.exports = b),
            i(
              r => {
                f = a(r);
                var o,
                  i = () =>
                    f.map(e => {
                      if (e[n]) throw e[n];
                      return e[t];
                    }),
                  s = new Promise(t => {
                    (o = () => t(i)).r = 0;
                    var r = e => e !== u && !d.has(e) && (d.add(e), e && !e.d && (o.r++, e.push(o)));
                    f.map(t => t[e](r));
                  });
                return o.r ? s : i();
              },
              e => (e ? l((b[n] = e)) : c(p), o(u))
            ),
            u && u.d < 0 && (u.d = 0);
        };
      })(),
      (r.n = e => {
        var t = e && e.__esModule ? () => e.default : () => e;
        return r.d(t, { a: t }), t;
      }),
      (() => {
        var e,
          t = Object.getPrototypeOf ? e => Object.getPrototypeOf(e) : e => e.__proto__;
        r.t = function (n, o) {
          if ((1 & o && (n = this(n)), 8 & o || ("object" == typeof n && n && ((4 & o && n.__esModule) || (16 & o && "function" == typeof n.then))))) return n;
          var a = Object.create(null);
          r.r(a);
          var i = {};
          e = e || [null, t({}), t([]), t(t)];
          for (var s = 2 & o && n; "object" == typeof s && !~e.indexOf(s); s = t(s))
            Object.getOwnPropertyNames(s).forEach(e => {
              i[e] = () => n[e];
            });
          return (i.default = () => n), r.d(a, i), a;
        };
      })(),
      (r.d = (e, t) => {
        for (var n in t) r.o(t, n) && !r.o(e, n) && Object.defineProperty(e, n, { enumerable: !0, get: t[n] });
      }),
      (r.f = {}),
      (r.e = e => Promise.all(Object.keys(r.f).reduce((t, n) => (r.f[n](e, t), t), []))),
      (r.hmd = e => (
        (e = Object.create(e)).children || (e.children = []),
        Object.defineProperty(e, "exports", {
          enumerable: !0,
          set: () => {
            throw Error("ES Modules may not assign module.exports or exports.*, Use ESM export syntax, instead: " + e.id);
          }
        }),
        e
      )),
      (r.u = e => "async/" + e + ".js"),
      (r.miniCssF = e => "" + e + ".css"),
      (() => {
        r.g = (() => {
          if ("object" == typeof globalThis) return globalThis;
          try {
            return this || Function("return this")();
          } catch (e) {
            if ("object" == typeof window) return window;
          }
        })();
      })(),
      (r.o = (e, t) => Object.prototype.hasOwnProperty.call(e, t)),
      (() => {
        var e = {},
          t = "@leap-cosmos/extension:";
        r.l = function (n, o, a, i) {
          if (e[n]) {
            e[n].push(o);
            return;
          }
          if (void 0 !== a)
            for (var s, u, f = document.getElementsByTagName("script"), c = 0; c < f.length; c++) {
              var l = f[c];
              if (l.getAttribute("src") == n || l.getAttribute("data-webpack") == t + a) {
                s = l;
                break;
              }
            }
          s ||
            ((u = !0),
            ((s = document.createElement("script")).charset = "utf-8"),
            (s.timeout = 120),
            r.nc && s.setAttribute("nonce", r.nc),
            s.setAttribute("data-webpack", t + a),
            (s.src = n)),
            (e[n] = [o]);
          var d = function (t, r) {
              (s.onerror = s.onload = null), clearTimeout(p);
              var o = e[n];
              if (
                (delete e[n],
                s.parentNode && s.parentNode.removeChild(s),
                o &&
                  o.forEach(function (e) {
                    return e(r);
                  }),
                t)
              )
                return t(r);
            },
            p = setTimeout(d.bind(null, void 0, { type: "timeout", target: s }), 12e4);
          (s.onerror = d.bind(null, s.onerror)), (s.onload = d.bind(null, s.onload)), u && document.head.appendChild(s);
        };
      })(),
      (r.r = e => {
        "undefined" != typeof Symbol && Symbol.toStringTag && Object.defineProperty(e, Symbol.toStringTag, { value: "Module" }),
          Object.defineProperty(e, "__esModule", { value: !0 });
      }),
      (r.nmd = e => ((e.paths = []), e.children || (e.children = []), e)),
      (r.nc = void 0),
      (() => {
        var e = [];
        r.O = (t, n, o, a) => {
          if (n) {
            a = a || 0;
            for (var i = e.length; i > 0 && e[i - 1][2] > a; i--) e[i] = e[i - 1];
            e[i] = [n, o, a];
            return;
          }
          for (var s = 1 / 0, i = 0; i < e.length; i++) {
            for (var [n, o, a] = e[i], u = !0, f = 0; f < n.length; f++)
              (!1 & a || s >= a) && Object.keys(r.O).every(e => r.O[e](n[f])) ? n.splice(f--, 1) : ((u = !1), a < s && (s = a));
            if (u) {
              e.splice(i--, 1);
              var c = o();
              void 0 !== c && (t = c);
            }
          }
          return t;
        };
      })(),
      (r.p = "/"),
      (r.rv = () => "1.2.8"),
      (r.v = function (e, t, n, o) {
        var a = fetch(r.p + "" + n + ".module.wasm"),
          i = function () {
            return a
              .then(function (e) {
                return e.arrayBuffer();
              })
              .then(function (e) {
                return WebAssembly.instantiate(e, o);
              })
              .then(function (t) {
                return Object.assign(e, t.instance.exports);
              });
          };
        return a.then(function (t) {
          return "function" == typeof WebAssembly.instantiateStreaming
            ? WebAssembly.instantiateStreaming(t, o).then(
                function (t) {
                  return Object.assign(e, t.instance.exports);
                },
                function (e) {
                  if ("application/wasm" !== t.headers.get("Content-Type"))
                    return (
                      console.warn(
                        "`WebAssembly.instantiateStreaming` failed because your server does not serve wasm with `application/wasm` MIME type. Falling back to `WebAssembly.instantiate` which is slower. Original error:\n",
                        e
                      ),
                      i()
                    );
                  throw e;
                }
              )
            : i();
        });
      }),
      (() => {
        var e = { 2980: 0 };
        (r.f.j = function (t, n) {
          var o = r.o(e, t) ? e[t] : void 0;
          if (0 !== o) {
            if (o) n.push(o[2]);
            else {
              var a = new Promise((r, n) => (o = e[t] = [r, n]));
              n.push((o[2] = a));
              var i = r.p + r.u(t),
                s = Error();
              r.l(
                i,
                function (n) {
                  if (r.o(e, t) && (0 !== (o = e[t]) && (e[t] = void 0), o)) {
                    var a = n && ("load" === n.type ? "missing" : n.type),
                      i = n && n.target && n.target.src;
                    (s.message = "Loading chunk " + t + " failed.\n(" + a + ": " + i + ")"),
                      (s.name = "ChunkLoadError"),
                      (s.type = a),
                      (s.request = i),
                      o[1](s);
                  }
                },
                "chunk-" + t,
                t
              );
            }
          }
        }),
          (r.O.j = t => 0 === e[t]);
        var t = (t, n) => {
            var o,
              a,
              [i, s, u] = n,
              f = 0;
            if (i.some(t => 0 !== e[t])) {
              for (o in s) r.o(s, o) && (r.m[o] = s[o]);
              if (u) var c = u(r);
            }
            for (t && t(n); f < i.length; f++) (a = i[f]), r.o(e, a) && e[a] && e[a][0](), (e[a] = 0);
            return r.O(c);
          },
          n = (self.webpackChunk_leap_cosmos_extension = self.webpackChunk_leap_cosmos_extension || []);
        n.forEach(t.bind(null, 0)), (n.push = t.bind(null, n.push.bind(n)));
      })(),
      (r.ruid = "bundler=rspack@1.2.8");
    var n = r.O(void 0, ["2072", "3361", "2118", "5401", "9821"], function () {
      return r(17204);
    });
    n = r.O(n);
  })();
